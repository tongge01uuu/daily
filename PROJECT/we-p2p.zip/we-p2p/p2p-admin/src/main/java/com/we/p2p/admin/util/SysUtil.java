package com.we.p2p.admin.util;

import com.we.p2p.admin.util.orm.page.PageQuery;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;

@Component("sysUtil")
@Scope("singleton")
public class SysUtil {
	/**
	 * MD5加密算法
	 * 
	 * @param encryptStr
	 * @return
	 */
	public static String encryptByMd5(String encryptStr) {
		String md5String = null;

		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(encryptStr.getBytes());
			byte b[] = md.digest();

			int i;

			StringBuffer buf = new StringBuffer("");
			for (int offset = 0; offset < b.length; offset++) {
				i = b[offset];
				if (i < 0)
					i += 256;
				if (i < 16)
					buf.append("0");
				buf.append(Integer.toHexString(i));
			}

			md5String = buf.toString();// 32位的加密
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		// System.out.println(md5String);
		return md5String;
	}

	/**
	 * 对象转换为Json字符串
	 * 
	 * @param o
	 * @return
	 * @throws Exception
	 */
	public static String toJsonStr(Object o) throws Exception {
		String jsonStr = null;
		ObjectMapper objectMapper = new ObjectMapper();
		jsonStr = objectMapper.writeValueAsString(o);

		return jsonStr;
	}

	public static boolean isEmpty(String s) {
		return s == null || "".equals(s);
	}

	public static boolean isEmptyCollection(Collection c) {
		return c == null || c.size() <= 0;
	}

	/**
	 *判断对象是否是空
	 * by agree
	 */
	public static boolean isEmptyObject(Object o) {
		return o == null || "".equals(o);
	}
	
	/**
	 * 将str的首字母改成大写
	 * 
	 * @param str
	 * @return
	 */
	public static String changeFirstCharUpper(String str) {
		String first = str.substring(0, 1);
		return str.replaceFirst(first, first.toUpperCase());
	}

	public static void responseJSON(HttpServletResponse response,
			String resultJsonStr) {
		try {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.write(resultJsonStr);
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 处理datagrid order by，如支持多个字段排序，扩展此方法即可
	 * 
	 * @param pageQuery
	 * @return
	 */
	public static String dealOrderby(PageQuery pageQuery, String attrStr,
									 String fieldStr) {
		String orderByStr = "";
		String sortAttr = pageQuery.getSort();
		String order = pageQuery.getOrder();
		String[] attrs = null;
		String[] fields = null;

		if (attrStr != null && !"".equals(attrStr.trim())) {
			attrs = attrStr.split(",");
		}
		if (fieldStr != null && !"".equals(fieldStr.trim())) {
			fields = fieldStr.split(",");
		}
		if (attrs == null || fields == null)
			return "";
		if (sortAttr == null || "".equals(sortAttr.trim()))
			return "";

		if (order == null || "".equals(order.trim())) {
			order = "asc";
		}
		for (int i = 0; i < attrs.length; ++i) {
			if (sortAttr.equals(attrs[i])) {
				orderByStr = fields[i] + " " + order;
			}
		}

		return orderByStr;
	}

}
