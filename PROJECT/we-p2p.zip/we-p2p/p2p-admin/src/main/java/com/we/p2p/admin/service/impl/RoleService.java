package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import com.we.p2p.admin.dao.UserRoleDao;
import com.we.p2p.admin.entity.FrmSysRoleResc;
import com.we.p2p.admin.entity.FrmSysUserRoleExample;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.dao.RescDao;
import com.we.p2p.admin.dao.RoleAuthDao;
import com.we.p2p.admin.dao.RoleRescDao;
import com.we.p2p.admin.util.CriteriaUtil;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.service.RescServiceI;
import com.we.p2p.admin.service.RoleServiceI;
import com.we.p2p.admin.util.ObjectUtil;
import com.we.p2p.admin.dao.RoleDao;
import com.we.p2p.admin.dao.AuthorityDao;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.entity.FrmSysRoleExample;
import com.we.p2p.admin.entity.FrmSysRoleRescExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.we.p2p.admin.entity.FrmSysAuthority;
import com.we.p2p.admin.entity.FrmSysAuthorityExample;
import com.we.p2p.admin.entity.FrmSysRescExample;
import com.we.p2p.admin.entity.FrmSysRoleAuth;
import com.we.p2p.admin.entity.FrmSysRoleAuthExample;
import com.we.p2p.admin.entity.FrmSysUserRole;
import com.we.p2p.admin.entity.RoleAuthNode;
import com.we.p2p.admin.entity.RoleRescNode;

/**
 * @author 大辉郎
 *
 * 2016-5-9
 */
@Service("roleService")
public class RoleService implements RoleServiceI {
	private RoleDao roleDao;
	private UserRoleDao userRoleDao;
	private RoleRescDao roleRescDao;
	private RescDao rescDao;
	private AuthorityDao authorityDao;
	private RoleAuthDao roleAuthDao;
	private RescServiceI rescServiceI;
	
	
	public RescServiceI getRescServiceI() {
		return rescServiceI;
	}

	@Autowired
	public void setRescServiceI(RescServiceI rescServiceI) {
		this.rescServiceI = rescServiceI;
	}


	public RoleAuthDao getRoleAuthDao() {
		return roleAuthDao;
	}

	@Autowired
	public void setRoleAuthDao(RoleAuthDao roleAuthDao) {
		this.roleAuthDao = roleAuthDao;
	}

	public AuthorityDao getAuthorityDao() {
		return authorityDao;
	}

	@Autowired
	public void setAuthorityDao(AuthorityDao authorityDao) {
		this.authorityDao = authorityDao;
	}

	public RescDao getRescDao() {
		return rescDao;
	}

	@Autowired
	public void setRescDao(RescDao rescDao) {
		this.rescDao = rescDao;
	}

	public RoleRescDao getRoleRescDao() {
		return roleRescDao;
	}

	@Autowired
	public void setRoleRescDao(RoleRescDao roleRescDao) {
		this.roleRescDao = roleRescDao;
	}

	public RoleDao getRoleDao() {
		return roleDao;
	}

	@Autowired
	public void setRoleDao(RoleDao roleDao) {
		this.roleDao = roleDao;
	}

	public UserRoleDao getUserRoleDao() {
		return userRoleDao;
	}

	@Autowired
	public void setUserRoleDao(UserRoleDao userRoleDao) {
		this.userRoleDao = userRoleDao;
	}

	/**
	 * 查询操作
	 */
	@Override
	public PageList<FrmSysRole> loadRole(PageQuery pageQuery, FrmSysRole role) {
		FrmSysRoleExample example = new FrmSysRoleExample();
		String roleName = role.getRoleName();
		String roleDesc = role.getRoleDesc();
		FrmSysRoleExample.Criteria criteria = example.createCriteria();
		if (roleName != null && !"".equals(roleName)) {
			criteria.andRoleNameLike("%" + roleName + "%");
		}
		if (roleDesc != null && !"".equals(roleDesc)) {
			criteria.andRoleDescLike("%" + roleDesc + "%");
		}
		
		String _ORDER_ATTRS = "roleName,caseInspectLvl,status";//根据逗号划分，不能空格
		String _ORDER_FIELDS = "ROLE_NAME,CASE_INSPECT_LVL,STATUS";
		String orderStr = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS,
				_ORDER_FIELDS);
		if (!"".equals(orderStr)) {
			example.setOrderByClause(orderStr);
		}

		return this.roleDao.findPage(pageQuery, example);
	}
	
	/**
	 * @author 大辉郎
	 * 时间：2013-7-10
	 */
	@Override
	public List<FrmSysRole> getRole (
			FrmSysRole role, long userId) {
		
		FrmSysRoleExample example = new FrmSysRoleExample();
		List roleList = getRoleIdInfo(userId);
		FrmSysRoleExample.Criteria criteria = example.createCriteria();
		List allRole = getRoleIds();
		
		if (null == roleList || roleList.size() ==0){
			criteria.andRoleIdIn(allRole);
	
		}else{
			criteria.andRoleIdNotIn(roleList);
			
		}
		return this.roleDao.findAll(example);
	}

	/**
	 * @author 大辉郎
	 * 时间：2013-6-25
	 */
	@Override
	public List<FrmSysRole> getUserRole(FrmSysRole role, long userId) {
		List<FrmSysRole> roleInfo = new PageList<>();
		FrmSysRoleExample example = new FrmSysRoleExample();
		List roles = getRoleIdInfo(userId);
		List allRole = getRoleIds();
		FrmSysRoleExample.Criteria criteria = example.createCriteria();
		if (null == roles || roles.size() ==0){
			criteria.andRoleIdIsNull();
	
		}else{
			criteria.andRoleIdIn(roles);
			
		}
		 roleInfo=this.roleDao.findAll(example);
		return roleInfo;
	}

	/**
	 * @author 大辉郎
	 * @return
	 * */
	@Override
	public List getRoleIdInfo(long userId) {

		List roleId = new ArrayList();
		List<FrmSysUserRole> all = new ArrayList<>();
		FrmSysUserRoleExample example = new FrmSysUserRoleExample();
		example.createCriteria().andUserIdEqualTo(userId);
		all = this.userRoleDao.findAll(example);
		for (FrmSysUserRole f : all) {
			roleId.add(f.getRoleId());
		}
		return roleId;
	}
	
	/**
	 * @author 大辉郎
	 * @return
	 * */
	@Override
	public List getRoleIds() {

		List roleId = new ArrayList();
		List<FrmSysRole> all = new ArrayList<>();
		all = this.roleDao.getAll();
		for (FrmSysRole f : all) {
			roleId.add(f.getRoleId());
		}
		return roleId;
	}
	
	/**
	 * 新增操作
	 */
	@Override
	public int createRole(FrmSysRole role) {
	//	role.setRoleId(KeyGenerator.getNextKey(role.getClass().getSimpleName()));
		role.setRoleId(KeyGenerator.getNextKey("frm_sys_role", "role_id"));
		int result = this.roleDao.save(role);

		return result;
	}

	/**
	 * 修改操作
	 */
	@Override
	public int updateRoleByPriKey(FrmSysRole role) {
		int result = this.roleDao.updateSelective(role);
		return result;
	}

	/**
	 * 删除操作
	 */
	@Override
	public int deleteRoleByPriKey(long roleId) {
		int result = this.roleDao.deleteById(roleId);
		return result;
	}

	/**
	 * 得到修改表单需要的数据
	 */
	@Override
	public FrmSysRole getRoleByPrikey(FrmSysRole role) {
		role = this.roleDao.getById(role.getRoleId());

		return role;
	}

	/**
	 * 通过roleId得到对应的resc
	 */
	public List<FrmSysRoleResc> getRescsByPrikey(FrmSysRole role) {
		FrmSysRoleRescExample example = new FrmSysRoleRescExample();
		example.createCriteria().andRoleIdEqualTo(role.getRoleId());

		// List<FrmSysResc> frmSysRescs = new ArrayList<FrmSysResc>();
		// for (int i = 0; i < frmSysRoleRescList.size(); i++) {
		// System.out.println(frmSysRoleRescList.get(i).getRescId());
		// frmSysRescs.add(this.frmSysRescMapper.selectByPrimaryKey(frmSysRoleRescList.get(i).getRescId()));
		// }

		return this.roleRescDao.findAll(example);
	}

	/**
	 * 获取角色模块的内容
	 */
	@Override
	public RoleRescNode loadRoleResc(FrmSysRole role) {
		FrmSysRescExample example = new FrmSysRescExample();
		FrmSysRescExample.Criteria criteria = example.createCriteria();
		criteria.andRescTypeEqualTo("M");
		criteria.andRescStatusEqualTo("1");
		example.setOrderByClause("RESC_ID");
		
		List rescList = this.rescDao.findAll(example);

		List<RoleRescNode> roleRescNodeList = new ArrayList();
		
		return this.generatorRoleRescNode(rescList, roleRescNodeList, role);
	}

	/**
	 * 对角色模块表内数据加工，形成界面展示菜单对象
	 * 
	 * @param rescList
	 * @return
	 */
	private RoleRescNode generatorRoleRescNode(List<FrmSysResc> rescList,
			List<RoleRescNode> roleRescNodeList, FrmSysRole role) {
		RoleRescNode roleRescNode = null;
		FrmSysResc sysResc = null;
		//构建总结点，以便全选 清空
		RoleRescNode headRoleRescNode = new RoleRescNode();
		headRoleRescNode.setPid("");
		headRoleRescNode.setId("T1");
		headRoleRescNode.setText("全部模块");
		
		if (rescList != null && rescList.size() > 0) {
			if (roleRescNodeList.size() == 0) {
				for (int i = 0; i < rescList.size(); i++) {
					sysResc = (FrmSysResc) rescList.get(i);
					if (sysResc.getParentId() == null
							|| sysResc.getParentId() == 0L) {
						roleRescNode = new RoleRescNode();
						roleRescNode.setPid("T1");
						roleRescNode.setId(String.valueOf(sysResc.getRescId()));
						roleRescNode.setText(sysResc.getRescTitle());
						roleRescNode.setUrl(sysResc.getRescUrl() == null ? ""
								: sysResc.getRescUrl());
						roleRescNode.setIconCls(sysResc.getRescIcon());
						roleRescNode.setIsLeaf(sysResc.getIsLeaf());
						roleRescNode.setSeq(sysResc.getRescSeq());
						getChild(roleRescNode, rescList, role);
						roleRescNodeList.add(roleRescNode);
					}
				}
				headRoleRescNode.setChildren(roleRescNodeList);
			}
		}

		return headRoleRescNode;
	}

	/**
	 * 获取RoleRescNode的子节点
	 * 
	 * @param rescList
	 */
	private void getChild(RoleRescNode roleRescNode, List<FrmSysResc> rescList,
			FrmSysRole role) {
		if ("Y".equals(roleRescNode.getIsLeaf()))
			return;

		RoleRescNode childRoleRescNode = null;
		FrmSysResc sysResc = null;
		List<RoleRescNode> childList = new ArrayList();
		for (int i = 0; i < rescList.size(); i++) {
			sysResc = (FrmSysResc) rescList.get(i);
			if (sysResc.getParentId() != null
					&& Long.parseLong(roleRescNode.getId()) == sysResc
							.getParentId()) {
				childRoleRescNode = new RoleRescNode();
				childRoleRescNode.setPid(roleRescNode.getId());
				childRoleRescNode.setId(String.valueOf(sysResc.getRescId()));
				childRoleRescNode.setText(sysResc.getRescTitle());
				childRoleRescNode.setUrl(sysResc.getRescUrl());
				childRoleRescNode.setIconCls(sysResc.getRescIcon());
				childRoleRescNode.setIsLeaf(sysResc.getIsLeaf());
				childRoleRescNode.setSeq(sysResc.getRescSeq());

				List<FrmSysRoleResc> frmSysRoleRescs = getRescsByPrikey(role);
				if (frmSysRoleRescs != null) {
					for (int x = 0; x < frmSysRoleRescs.size(); x++) {
						if (childRoleRescNode.getId().equals(
								frmSysRoleRescs.get(x).getRescId().toString())) {
							childRoleRescNode.setChecked(true);
						}
					}
				}
				getChild(childRoleRescNode, rescList, role);
				childList.add(childRoleRescNode);
			}
		}
		roleRescNode.setChildren(childList);
	}

	/**
	 * 保存勾选的角色模块
	 */
	@Override
	public int saveRoleResc(long roleId, List<Long> rescIdList) {
		int result = 0;
		FrmSysRoleRescExample frmSysRoleRescExample = new FrmSysRoleRescExample();
		frmSysRoleRescExample.createCriteria().andRoleIdEqualTo(roleId);
		this.roleRescDao.deleteByExample(frmSysRoleRescExample);

		for (int i = 0; i < rescIdList.size(); i++) {
			FrmSysRoleResc frmSysRoleResc = new FrmSysRoleResc();
			frmSysRoleResc.setRoleId(roleId);
			frmSysRoleResc.setRescId(rescIdList.get(i));
			result = this.roleRescDao.save(frmSysRoleResc);
		}

		return result;
	}

	public FrmSysResc getRescByRescId(Long rescId){
		FrmSysResc frmSysResc = this.rescDao.getById(rescId);
		
		return frmSysResc;
	}
	
	
	

	
	/**
	 * 保存勾选的角色权限
	 */
	@Override
	public int saveRoleAuth(long roleId, long[] authIdList) {

		int result = 0;
		FrmSysRoleAuthExample sysRoleAuthExample = new FrmSysRoleAuthExample();
		sysRoleAuthExample.createCriteria().andRoleIdEqualTo(roleId);
		this.roleAuthDao.deleteByExample(sysRoleAuthExample);

		for (int i = 0; i < authIdList.length; i++) {
			FrmSysRoleAuth sysRoleAuth = new FrmSysRoleAuth();
			sysRoleAuth.setRoleId(roleId);
			sysRoleAuth.setAuthId(authIdList[i]);
			result = this.roleAuthDao.save(sysRoleAuth);
		}

		return result;
	}

	/**
	 * 同名则返回true
	 */
	@Override
	public Boolean checkRoleName(String roleName) {
		FrmSysRoleExample sysRoleExample = new FrmSysRoleExample();
		sysRoleExample.createCriteria().andRoleNameEqualTo(roleName);
		FrmSysRole frmSysRole = this.roleDao.findOne(sysRoleExample);
		if(frmSysRole==null||"".equals(frmSysRole)){
			return false;
		}
		
		return true;
	}
	
//	/**
//	 * 获取角色权限的内容
//	 */
//	@Override
//	public List<RoleAuthNode> loadRoleAuth(
//			FrmSysRole role) {
//		FrmWarningToQueueCondExample example = new FrmWarningToQueueCondExample();
//		example.createCriteria().andQueueIdEqualTo(warningQueue.getQueueId());
//		example.setOrderByClause("COND_ID");
//		List<FrmWarningToQueueCond> warningToQueueCondList = this.warningToQueueCondDao
//				.findAll(example);
//
//		List<WarningToQueueNode> warningQueueNodeList = new ArrayList();
//		warningQueueNodeList = this.generatorWarningToQueueNode(warningToQueueCondList,
//				warningQueueNodeList);
//		
//		return warningQueueNodeList;
//	}
//
	
	/**
	 * 得到所选模块的权限
	 */
	@Override
	public RoleAuthNode getRoleAuthTree(FrmSysRole role) {
		//得到所有的模块
		FrmSysRescExample example = new FrmSysRescExample();
		FrmSysRescExample.Criteria criteria = example.createCriteria();
		criteria.andRescTypeEqualTo("M");
		criteria.andRescStatusEqualTo("1");
		example.setOrderByClause("RESC_ID");
		
		List<FrmSysResc> allRescList = this.rescDao.findAll(example);
		
		/**
		 * 用权限就可判断是否选中该模块，所以不必多余操作
		 */
//		//得到角色的模块
//		List<FrmSysRoleResc> frmSysRoleRescs =  getRescsByPrikey(role);
//		List<FrmSysResc> roleRescList = new ArrayList<>();
//		for(FrmSysRoleResc frmSysRoleResc : frmSysRoleRescs){
//			roleRescList.add(getRescByRescId(frmSysRoleResc.getRescId()));
//		}
		
		/**
		 * 通过模块搜出对应权限既是所有权限
		 */
//		//得到所有权限
//		List<FrmSysAuthority> allAuthList = this.authorityDao.getAll();
		
		//得到该角色的权限
		FrmSysRoleAuthExample roleAuthExample = new FrmSysRoleAuthExample();
		roleAuthExample.createCriteria().andRoleIdEqualTo(role.getRoleId());
		List<FrmSysRoleAuth> roleAuthList = this.roleAuthDao.findAll(roleAuthExample);
		
		//构建树节点
		List<RoleAuthNode> roleAuthNodes = new ArrayList<>();
		
		return this.generatorRoleAuthNode(allRescList, roleAuthNodes, roleAuthList);
	}
	
	/**
	 * 对角色权限模块表内数据加工，形成界面展示菜单对象
	 * 
	 * @param
	 * @return
	 */
	private RoleAuthNode generatorRoleAuthNode(
			List<FrmSysResc> allRescList,
//			List<FrmSysAuthority> allAuthList,
//			List<FrmSysResc> roleRescList,
			List<RoleAuthNode> roleAuthNodeList,
			List<FrmSysRoleAuth> roleAuthList) {
		RoleAuthNode headRoleAuthNode = new RoleAuthNode();//总节点
		RoleAuthNode parentRoleAuthNode = null;//模块父节点
		RoleAuthNode roleAuthNode = null;//权限父节点，模块子节点
		RoleAuthNode childRoleAuthNode = null;//子节点
		List<RoleAuthNode> childNodeList = null;
		List<RoleAuthNode> parentRoleAuthNodeList = null;
		
		headRoleAuthNode.setPid("");
		headRoleAuthNode.setId("T1");
		headRoleAuthNode.setText("所有模块权限");

		if (roleAuthNodeList.size() == 0) {
			for (FrmSysResc resc : allRescList) {
				
				//如果是第一父节点则跳过
				if(SysUtil.isEmptyObject(resc)||resc.getIsLeaf().equals("N")){
					continue;
				}
				
				//得到模块的所有权限
				FrmSysAuthorityExample sysAuthorityExample = new FrmSysAuthorityExample();
				sysAuthorityExample.createCriteria().andRescIdEqualTo(resc.getRescId());
				List<FrmSysAuthority> authList = this.authorityDao.findAll(sysAuthorityExample);
				
				//如果子節點為空則跳過
				if(authList.isEmpty()){
					continue;
				}else{//设置父节点--模块
					roleAuthNode = new RoleAuthNode();
					roleAuthNode.setPid("f"+resc.getParentId().toString());
					roleAuthNode.setId("p"+resc.getRescId().toString());//增加P字母是为了在保存角色权限的时候避免加入模块ID
					roleAuthNode.setText(resc.getRescName());
				}
				
				childNodeList = new ArrayList<>();
				//通过权限设置子节点
				for(FrmSysAuthority sysAuthority : authList){
					childRoleAuthNode = new RoleAuthNode();
					childRoleAuthNode.setPid("p"+resc.getRescId().toString());
					childRoleAuthNode.setPname(resc.getRescName());
					childRoleAuthNode.setId(sysAuthority.getAuthId().toString());
					childRoleAuthNode.setText(sysAuthority.getAuthDesc());
					childRoleAuthNode.setIsAuthId(true);//以便判断是否是权限Id
					
					//跟选择的角色比较，如果是选中的则设为checked
					for(FrmSysRoleAuth roleAuth : roleAuthList){
						if(Long.parseLong(childRoleAuthNode.getId())==roleAuth.getAuthId()){
							childRoleAuthNode.setChecked(true);
						}
					}
					childNodeList.add(childRoleAuthNode);
				}
				
				roleAuthNode.setChildren(childNodeList);
				roleAuthNodeList.add(roleAuthNode);
				}
			
			parentRoleAuthNodeList = new ArrayList<>();
			List<FrmSysResc> parentRescs = new  ArrayList<FrmSysResc>();
			parentRescs.addAll(this.rescServiceI.getAllCurrentParent());
			//将为父节点的添加到第一父节点中去
			for(FrmSysResc frmSysResc : parentRescs){
				parentRoleAuthNode = new RoleAuthNode();
				parentRoleAuthNode.setPid("T1");
				parentRoleAuthNode.setId("f"+frmSysResc.getRescId().toString());
				parentRoleAuthNode.setText(frmSysResc.getRescName());
				List<RoleAuthNode> childParentRoleAuthNodeList = new ArrayList<>();
				for(RoleAuthNode authNode : roleAuthNodeList){
					if(authNode.getPid().equals(parentRoleAuthNode.getId())){
						authNode.setPname(parentRoleAuthNode.getText());
						childParentRoleAuthNodeList.add(authNode);
					}
				}
				
				//如果第一父節點的子节点为空则删掉
				if(childParentRoleAuthNodeList.isEmpty()){
					continue;
				}
				parentRoleAuthNode.setChildren(childParentRoleAuthNodeList);
				parentRoleAuthNodeList.add(parentRoleAuthNode);
			}
			}

		headRoleAuthNode.setChildren(parentRoleAuthNodeList);
		
		return headRoleAuthNode;
	}

	/** (non-Javadoc)
	 * @see RoleServiceI#findAllByTemplate(FrmSysRole)
	 * @author xtuali
	 * 根据模版查询所有role
	 * 时间：2013-7-9
	 */
	@Override
	public List<FrmSysRole> findAllByTemplate(FrmSysRole role) {
		FrmSysRoleExample example = new FrmSysRoleExample();
		try {
			CriteriaUtil.initEqualToCriteria(example.createCriteria(), role, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return roleDao.findAll(example);
	}
	/**
	 * (non-Javadoc)
	 * @see RoleServiceI#findAllUserId(Long)
	 * @author xtuali
	 * 时间：2013-7-9
	 * @throws Exception 
	 */
	@Override
	public List<FrmSysRole> findAllUserId(Long userId) throws Exception{
		FrmSysUserRole userRole = new FrmSysUserRole();
		userRole.setUserId(userId);
		FrmSysUserRoleExample example = new FrmSysUserRoleExample();
		FrmSysUserRoleExample.Criteria criteira = example.createCriteria();
		CriteriaUtil.initEqualToCriteria(criteira, userRole, null);
		List<FrmSysUserRole> userRoles = userRoleDao.findAll(example);
		
		
		List<Long> roleIds = ObjectUtil.getElementsFieldValue(userRoles, "roleId");
		
		FrmSysRoleExample roleExample = new FrmSysRoleExample();
		roleExample.createCriteria().andRoleIdIn(roleIds);
		
		return roleDao.findAll(roleExample);
		
	}
	/** (non-Javadoc)
	 * @see RoleServiceI#getRoleAuths(Long)
	 * @author xtuali
	 * 时间：2013-7-10
	 */
	@Override
	public List<FrmSysAuthority> getRoleAuths(Long roleId) {
		FrmSysRoleAuthExample roleAuthExample = new FrmSysRoleAuthExample();
		roleAuthExample.createCriteria().andRoleIdEqualTo(roleId);
		List<FrmSysRoleAuth> roleAuthList = this.roleAuthDao.findAll(roleAuthExample);
		
		FrmSysAuthority authority = new FrmSysAuthority();
		FrmSysAuthorityExample example = new FrmSysAuthorityExample();
		example.createCriteria().andAuthIdIn(ObjectUtil.getElementsFieldValue(roleAuthList, "authId"));
		return authorityDao.findAll(example);
	}
	/** (non-Javadoc)
	 * @see RoleServiceI#getRoleRescs(Long)
	 * @author xtuali
	 * 时间：2013-7-10
	 */
	@Override
	public List<FrmSysResc> getRoleRescs(Long roleId) {
		List<FrmSysResc> rescs = this.rescDao.selectByRoleId(roleId);
		return rescs;
	}

	@Override
	public List<Long> getRescIdsByAuthIds(long[] authIdList){
		List<Long> rescIdList = new ArrayList<>();
		
		for(Long authId : authIdList){
			FrmSysAuthorityExample authorityExample = new FrmSysAuthorityExample();
			authorityExample.createCriteria().andAuthIdEqualTo(authId);
			rescIdList.add(authorityDao.findOne(authorityExample).getRescId());
		}
		
		HashSet set = new HashSet(rescIdList);//去除重复值
		rescIdList.clear();
		rescIdList.addAll(set);
		
		return rescIdList;
	}
}
