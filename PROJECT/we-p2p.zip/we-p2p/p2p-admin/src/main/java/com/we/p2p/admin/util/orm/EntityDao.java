package com.we.p2p.admin.util.orm;

import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;

import java.io.Serializable;
import java.util.List;


public interface EntityDao<E, PK extends Serializable> {

	public Object getById(PK id);

	public int deleteById(PK id);
	public int deleteByExample(Object exampleParam);

	public int save(E entity);
	public int saveSelective(E entity);
	

	public int update(E entity);
	public int updateSelective(E entity);

	public int saveOrUpdate(E entity);

	public List<E> getAll();

	public List<E> findAll(Object exampleParam);

	public List<E> findAll(String statement, Object param);

	public PageList<E> findPage(PageQuery pq, Object exampleParam);

	public PageList<E> findPage(String statement, PageQuery pq, Object param);

	public PageList<E> findPage(String statement, String countStatement, PageQuery pq, Object param);

	public E findOne(Object exampleParam);

	
}
