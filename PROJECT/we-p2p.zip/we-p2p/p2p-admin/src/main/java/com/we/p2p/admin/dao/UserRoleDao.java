package com.we.p2p.admin.dao;

import com.we.p2p.admin.entity.FrmSysUserRole;
import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import org.springframework.stereotype.Repository;

@Repository
public class UserRoleDao extends BaseMybatisDao<FrmSysUserRole, Long> {
	
	@Override
	public String getNamespace() {
		return FrmSysUserRoleMapper.class.getCanonicalName();
	}

}
