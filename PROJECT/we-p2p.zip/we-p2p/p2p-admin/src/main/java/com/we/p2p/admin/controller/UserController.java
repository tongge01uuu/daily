package com.we.p2p.admin.controller;

/**
 * @author  率治国 niubi
 * @version 
 * Create Date:2013-5-9
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.entity.UserRole;
import com.we.p2p.admin.service.DeptServiceI;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.service.UserServiceI;
import com.we.p2p.admin.service.RoleServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.entity.FrmSysDept;
import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.entity.FrmDataDictItem;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/user")
@SessionAttributes("user")
public class UserController {
	private SysUtil sysUtil;
	private UserServiceI userService;
	private DeptServiceI deptServiceI;
	private RoleServiceI roleService;

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	public UserServiceI getUserService() {
		return userService;
	}

	@Autowired
	public void setUserService(UserServiceI userService) {
		this.userService = userService;
	}

	public DeptServiceI getDeptServiceI() {
		return deptServiceI;
	}

	@Autowired
	public void setDeptServiceI(DeptServiceI deptServiceI) {
		this.deptServiceI = deptServiceI;
	}

	public RoleServiceI getRoleService() {
		return roleService;
	}

	@Autowired
	public void setRoleService(RoleServiceI roleService) {
		this.roleService = roleService;
	}

	/**
	 * Description 读取全部用户信息
	 * 
	 * @param user
	 * @param user
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::LIST")
	@RequestMapping(value = "userlist")
	@ResponseBody
	@MethodDesc(value = "用户列表显示（查询）", module = "系统管理")
	public DataGrid getUserList(PageQuery pageQuery, FrmSysUser user) {

		PageList<FrmSysUser> userList = null;
		DataGrid result = new DataGrid();
		try {
			userList = this.userService.getUserPageList(pageQuery, user);
			if (userList != null) {
				result.setTotal((long) userList.getTotal());
				result.setRows(userList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Description 转到增加新用户信息
	 * 
	 * @param
	 * @return modelView
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::ADD")
	@RequestMapping(value = "toAddUser")
	public ModelAndView toAddUser() {
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("system/modifyUser");
		modelView.addObject("flag", "ADD");
		return modelView;
	}

	/**
	 * 
	 * Description 进入修改用户界面，获取修改的用户信息
	 * 
	 * @param userId
	 * @return modelView
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::MODIFY")
	@RequestMapping(value = "toUpdateUser")
	public ModelAndView toUpdateUser(FrmSysUser users) {

		try {
			users = this.userService.getUserByPriKey(users);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("system/modifyUser");
		modelView.addObject("flag", "UPDATE");
		modelView.addObject("users", users);
		return modelView;
	}

	/**
	 * Description 添加、修改用户信息
	 * 
	 * @param user
	 * @param flag
	 * @param response
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequestMapping(value = "modifyUser")
	@ResponseBody
	@MethodDesc(value = "修改（update）或添加(Add)", module = "用户管理")
	@ExtractValue(argIndex = 1, fieldsName = { "#self#" }, fieldsDesc = {"操作内容" })
	public void modifyUser(FrmSysUser user, String flag,HttpServletRequest request,HttpServletResponse response) {
		Map<String, Object> result = new HashMap();
		String resultJsonStr = null;
		try {
			if ("ADD".equals(flag)) {
				/*添加用户信息*/
				result = this.userService.addUser(user,request);
			} else if ("UPDATE".equals(flag)) {
				/*修改用户*/
				result = this.userService.updateUser(user);
			} else {
				result.put("success", false);
				result.put("msg", "用户信息添加异常，服务器端无法正常获取请求数据！");
			}
			resultJsonStr = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			e.printStackTrace();
			resultJsonStr = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(resultJsonStr);
				out.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
	
	

	/**
	 * Description 删除用户信息
	 * 
	 * @param ids
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::DELETE")
	@RequestMapping(value = "deleteUser")
	@ResponseBody
	@MethodDesc(value = "删除用户", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"条件ID" })
	public Map<String, Object> deleteUser(String ids) {
		Map<String, Object> result = new HashMap();

		try {
			if (ids != null && !"".equals(ids.trim())) {
				/*删除用户对应的角色信息*/
				this.userService.deleteUserRoleByKeys(ids);
				/*删除用户信息*/
				this.userService.deleteUserByKeys(ids);
				result.put("success", true);
				result.put("msg", "用户信息删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户信息删除失败，服务器端未获得要删除的用户信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户信息删除失败，服务器端处理异常！");
		}

		return result;
	}
	
	/**
	 * Description 初始化用户密码
	 * 
	 * @param ids
	 * @return result
	 * @author 大辉郎 Create Date:2013-8-23
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::INITIALIZE")
	@RequestMapping(value = "toInitializePwd")
	@ResponseBody
	@MethodDesc(value = "初始化用户密码", module = "系统管理")
	public Map<String, Object> toInitializePwd(String ids) {
		Map<String, Object> result = new HashMap();

		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.userService.initializePwd(ids);
				result.put("success", true);
				result.put("msg", "用户密码初始化成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户密码初始化失败，服务器端未获得要用户密码初始化的信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户密码初始化失败，服务器端处理异常！");
		}

		return result;
	}
	
	/**
	 * Description 进入用戶角色管理界面
	 * 
	 * @param userId
	 * @return modelViewRole
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequiresPermissions("SYS_MANAGE_USER:::CFG_ROLE")
	@RequestMapping(value = "toUserRoleManager")
	public ModelAndView toUserRoleManager(long userId) {

		ModelAndView modelViewRole = new ModelAndView();
		FrmSysUser users = new FrmSysUser();
		users = this.userService.getUserByUserId(userId);
		modelViewRole.setViewName("system/userRoleManager");// 新的URL
		modelViewRole.addObject("users", users);// 传递UserId
		return modelViewRole;
	}

	@RequestMapping("getAllUsers")
	@ResponseBody
	public List<FrmSysUser> getAllUser(FrmSysUser user) {
		return userService.getUserList(user);
	}

	/**
	 * Description 用户管理，角色设置，查询用户没有角色
	 * 
	 * @param role
	 * @param userId
	 * @return dataGrid
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "getRole")
	@ResponseBody
	public DataGrid getRole(FrmSysRole role, long userId) {
		List<FrmSysRole> roleList = null;
		DataGrid dataGrid = new DataGrid();

		try {
			roleList = this.roleService.getRole(role, userId);
			if (roleList != null) {
				dataGrid.setRows(roleList);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return dataGrid;
	}

	/**
	 * Description 用户管理，角色设置，查询用户已有角色
	 * 
	 * @param role
	 * @param userId
	 * @return dataGrid
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "userRole")
	@ResponseBody
	public DataGrid loadUserRole(FrmSysRole role, long userId) {

		List<FrmSysRole> roleList = null;
		List<UserRole> roleInfo = new PageList<UserRole>();
		DataGrid dataGrid = new DataGrid();
		FrmSysUser userInfo = new FrmSysUser();
		userInfo = getAUser(userId);

		try {
			roleList = this.roleService.getUserRole(role, userId);
			if (null == userInfo.getRoleId()) {

				for (int i = 0; i < roleList.size(); i++) {
					UserRole roles = new UserRole();
					if (roleList.get(i).getRoleId() == userInfo.getRoleId()) {
						roles.setRoleId(roleList.get(i).getRoleId());
						roles.setRoleName(roleList.get(i).getRoleName());
						roles.setDefaultRole("Y");
					} else {
						roles.setRoleId(roleList.get(i).getRoleId());
						roles.setRoleName(roleList.get(i).getRoleName());
						roles.setDefaultRole("N");
					}
					roleInfo.add(roles);
				}
			} else {
				for (int i = 0; i < roleList.size(); i++) {
					UserRole roles = new UserRole();
					if (roleList.get(i).getRoleId() == userInfo.getRoleId()) {
						roles.setRoleId(roleList.get(i).getRoleId());
						roles.setRoleName(roleList.get(i).getRoleName());
						roles.setDefaultRole("Y");
					} else {
						roles.setRoleId(roleList.get(i).getRoleId());
						roles.setRoleName(roleList.get(i).getRoleName());
						roles.setDefaultRole("N");
					}
					roleInfo.add(roles);
				}

			}
			if (roleInfo != null) {
				dataGrid.setRows(roleInfo);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataGrid;
	}

	/**
	 * Description 用户管理，角色设置，删除包含默认角色
	 * 
	 * @param ids
	 * @param userId
	 * @return result
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "deleteDefautUserRole")
	@ResponseBody
	@MethodDesc(value = "删除默认角色", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"角色权限ID" })
	public Map<String, Object> deleteDefautUserRole(String ids, long userId) {
		Map<String, Object> result = new HashMap();
		FrmSysUser userInfo = new FrmSysUser();
		userInfo = this.userService.getUserByUserId(userId);
		try {
			if (ids != null && !"".equals(ids.trim())) {

				userInfo.setRoleId(null);
				this.userService.updateByPrimaryKey(userInfo);
				this.userService.deleteUserRole(ids, userId);
				result.put("success", true);
				result.put("msg", "用户角色取消成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户角色取消失败，服务器端未获得要取消的角色信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户角色取消失败，服务器端处理异常！");
		}

		return result;
	}

	/**
	 * Description 用户管理，角色设置，删除角色
	 * 
	 * @param ids
	 * @param userId
	 * @return result
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "deleteUserRole")
	@ResponseBody
	@MethodDesc(value = "删除角色", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"角色ID" })
	public Map<String, Object> deleteUserRole(String ids, long userId) {
		Map<String, Object> result = new HashMap();
		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.userService.deleteUserRole(ids, userId);
				result.put("success", true);
				result.put("msg", "用户角色取消成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户角色取消失败，服务器端未获得要取消的角色信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户角色取消失败，服务器端处理异常！");
		}

		return result;
	}

	/**
	 * Description 用户管理，角色设置，添加角色
	 * 
	 * @param ids
	 * @param userId
	 * @return result
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "addUserRole")
	@ResponseBody
	@MethodDesc(value = "添加角色", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"角色ID" })
	public Map<String, Object> addUserRole(String ids, long userId) {
		Map<String, Object> result = new HashMap();

		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.userService.addUserRoles(ids, userId);
				result.put("success", true);
				result.put("msg", "用户角色添加成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户角色添加失败，服务器端未获得要添加的角色信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户角色添加失败，服务器端处理异常！");
		}

		return result;
	}

	/**
	 * Description 用户管理，角色设置，添加默认角色
	 * 
	 * @param roleId
	 * @param userId
	 * @return result
	 * @author 大辉郎 Create Date:2013-6-25
	 */
	@RequestMapping(value = "defaultRole")
	@ResponseBody
	@MethodDesc(value = "设置默认角色", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"角色ID" })
	public Map<String, Object> addDefaultRole(long roleId, long userId) {

		Map<String, Object> result = new HashMap();
		FrmSysUser userList = new FrmSysUser();
		userList = this.userService.getUserByUserId(userId);
		try {
			if (roleId != 0 && userId != 0) {

			// 修改用户信息里面的roleId
			userList.setRoleId(roleId);
			this.userService.updateByPrimaryKeySelective(userList);
			result.put("success", true);
			result.put("msg", "用户默认角色添加成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户默认角色添加失败，服务器端未获得要添加的默认角色信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户默认角色添加失败，服务器端处理异常！");
		}

	    return result;
	}

	/***
	 * Description 获取资源类型
	 * 
	 * @param DICT_TYPE
	 * @return items
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequestMapping(value = "userType")
	@ResponseBody
	public List<FrmDataDictItem> getrescTypes(String DICT_TITLE) {
		DataDictionary dictionary = this.userService.getDictItems(DICT_TITLE);
		List<FrmDataDictItem> items = dictionary.getDictItemList();
		return items;
	}

	/***
	 * Description 检查用户ID是否存在
	 * 
	 * @param response
	 * @param loginId
	 * @param user
	 */
	@RequestMapping(value = "checkLoginId")
	@ResponseBody
	public void checkLoginId(HttpServletResponse response, String loginId) {
		response.setContentType("text/html;charset=utf-8");

		try {
			String id = URLDecoder.decode(loginId, "UTF-8");
			FrmSysUser use = new FrmSysUser();
			use.setLoginId(id);
			FrmSysUser result = this.userService.getUserByLoginId(loginId);
			PrintWriter out = response.getWriter();
			if (result != null) {
				out.println("该登录名已经存在，请重新填写");
			} else {
				out.print("恭喜，该登录名可以使用");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Description 添加用户时，取得机构信息
	 * 
	 * @param
	 * @return
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequestMapping(value = "getAllDept")
	@ResponseBody
	public List<FrmSysDept> getDeptId() {
		return this.userService.getDeptAll();

	}

	/**
	 * Description 添加用户时，取得角色信息
	 * 
	 * @param
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequestMapping(value = "getAllRole")
	@ResponseBody
	public List<FrmSysRole> getRoleId() {
		return this.userService.getRoleAll();

	}

	/**
	 * 根据传入的用户ID，获取该用户
	 * 
	 * @author hanson
	 * @param userId
	 * @param user
	 */
	@RequestMapping("getAUser")
	@ResponseBody
	public FrmSysUser getAUser(long userId) {

		FrmSysUser user = new FrmSysUser();
		try {
			user = this.userService.getUserByUserId(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	/**
	 * Description 修改用户基本信息
	 * 
	 * @param user
	 * @return result
	 * @author 大辉郎 Create Date:2013-8-12
	 */
	@RequestMapping(value = "basicUserInfoModfiy")
	@ResponseBody
	@MethodDesc(value = "修改用户基本信息", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "userId" }, fieldsDesc = {"用户ID" })
	public Map<String, Object> basicUserInfoModfiy(@ModelAttribute("user") User user) {
		Map<String, Object> result = new HashMap();

		try {
			if (user != null) {

				this.userService.updateByPrimaryKeySelective(user);
				result.put("success", true);
				result.put("msg", "用户基本信息修改成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户基本信息修改失败，服务器端未获得要修改的用户基本信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户基本信息修改失败，服务器端处理异常！");
		}

		return result;
	}
	
	/**
	 * Description 修改密码
	 * 
	 * @param user
	 * @param oldPassword
	 * @param newPassword
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@RequestMapping(value = "modifyPassWord")
	@ResponseBody
	@MethodDesc(value = "修改密码", module = "系统管理")
	@ExtractValue(argIndex = 2, fieldsName = { "userId" }, fieldsDesc = {"用户ID" })
	public Map<String, Object> modifyPassword(String oldPassword,
			String newPassword, @ModelAttribute("user") User user) {

		Map<String, Object> result = new HashMap<String, Object>();
		String pwd = sysUtil.encryptByMd5(oldPassword);
		String oldPwd = user.getPassword();

		if (!pwd.equals(oldPwd)) {
			result.put("msg", "用户原密码输入有误！请重新输入！");
		} else {
			try {
				if (user != null) {
					user.setPassword(sysUtil.encryptByMd5(newPassword));
					this.userService.updateByPrimaryKeySelective(user);
					result.put("success", true);
					result.put("msg", "用户密码修改成功！");
				} else{
					result.put("success", false);
					result.put("msg", "用户密码修改失败，服务器端未获得要修改的用户密码信息！");
				}
			} catch (Exception e) {
				e.printStackTrace();
				result.put("success", false);
				result.put("msg", "用户密码修改失败，服务器端处理异常！");
			}
		}

		return result;
	}
}