package com.we.p2p.admin.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.entity.RoleRescNode;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.service.RoleServiceI;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.we.p2p.admin.entity.RoleAuthNode;

/**
 * @author 大辉郎
 *         <p/>
 *         2016-5-9
 */
@Controller
@RequestMapping("/role")
@SessionAttributes("user")//得到session的值
public class RoleController {
    private SysUtil sysUtil;
    private RoleServiceI roleService;
    private static final Logger logger = LoggerFactory.getLogger(RoleController.class);

    public RoleServiceI getRoleService() {
        return roleService;
    }

    @Autowired
    public void setRoleService(RoleServiceI roleService) {
        this.roleService = roleService;
    }

    public SysUtil getSysUtil() {
        return sysUtil;
    }

    @Autowired
    public void setSysUtil(SysUtil sysUtil) {
        this.sysUtil = sysUtil;
    }

    /**
     * 进入角色模块管理界面
     *
     * @param role
     * @return
     */
    @RequiresPermissions("SYS_MANAGE_ROLE:::CFG_AUTH")
    @RequestMapping(value = "toRoleRescManager")
    public ModelAndView toRoleRescManager(FrmSysRole role) {

        ModelAndView modelViewRole = new ModelAndView();
        modelViewRole.setViewName("system/roleRescManager");//新的URL
        modelViewRole.addObject("role", role);//传递RoleId
        return modelViewRole;
    }

    /**
     * 进入增加角色界面
     *
     * @return
     */
    @RequiresPermissions("SYS_MANAGE_ROLE:::ADD")
    @RequestMapping(value = "toAddRole")
    public ModelAndView toAddRole() {
        ModelAndView modelViewRole = new ModelAndView();
        modelViewRole.setViewName("system/updateRole");//新的URL
        modelViewRole.addObject("flag", "ADD");//标志名
        return modelViewRole;
    }

    /**
     * 进入修改角色界面
     *
     * @return
     */
    @RequiresPermissions("SYS_MANAGE_ROLE:::MODIFY")
    @RequestMapping(value = "toUpdateRole")
    @ResponseBody
    public ModelAndView toUpdateRole(FrmSysRole role) {
        role = this.roleService.getRoleByPrikey(role);
        ModelAndView modelViewRole = new ModelAndView();
        modelViewRole.setViewName("system/updateRole");
        modelViewRole.addObject("flag", "UPDATE");//传递参数标志
        modelViewRole.addObject("role", role);//通过传递ID得到role
        return modelViewRole;
    }

    /**
     * 查询角色信息
     *
     * @return
     */
    @RequiresPermissions("SYS_MANAGE_ROLE:::LIST")
    @RequestMapping(value = "roleList")
    @ResponseBody
    public DataGrid loadRole(PageQuery pageQuery, FrmSysRole role) {
        PageList<FrmSysRole> roleList = null;
        DataGrid dataGrid = new DataGrid();

        try {
            roleList = this.roleService.loadRole(pageQuery, role);
            if (roleList != null) {
                dataGrid.setTotal((long) roleList.getTotal());
                dataGrid.setRows(roleList);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataGrid;
    }

    /**
     * 添加角色信息
     *
     * @return
     */
    @RequestMapping(value = "roleAdd")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> addRole(FrmSysRole role, User user) {
        Map<String, Object> result = new HashMap();

        try {
            if (!(sysUtil.isEmptyObject(role.getRoleName()) || sysUtil.isEmptyObject(role.getStatus()))) {
                role.setCreateTime(new Date());
                role.setLastModifyTime(new Date());
                role.setCreator(user.getUserId());
                //role.setStatus("1");//0代表无效，1代表有效
                role.setLastModifier(user.getUserId());

                this.roleService.createRole(role);
                result.put("success", true);
                result.put("msg", "角色信息添加成功！");
            } else {
                result.put("success", false);
                result.put("msg", "角色信息添加失败，填写的角色信息不完整！");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "角色信息添加失败，服务器端未获得要添加的角色信息！");
        }

        return result;
    }

    /**
     * 添加 修改角色信息
     *
     * @return
     */
    @RequestMapping(value = "modifyRole")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public void modifyRole(FrmSysRole role, String flag, @ModelAttribute("user") User user,
                           HttpServletResponse response) {
        Map<String, Object> result = new HashMap();
        String resultJsonStr = null;

        try {
            if ("ADD".equals(flag)) {
                result = this.addRole(role, user);
            } else if ("UPDATE".equals(flag)) {
                result = this.updateRole(role, user);
            } else {
                result.put("success", false);
                result.put("msg", "角色信息修改失败，填写的角色信息不完整！");
            }
            resultJsonStr = this.sysUtil.toJsonStr(result);
        } catch (Exception e) {
            e.printStackTrace();
            resultJsonStr = "{success:false,msg:'Json转换失败！'}";
        } finally {
            try {
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.write(resultJsonStr);
                out.flush();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 修改角色信息
     *
     * @param role
     * @return
     */
    @RequestMapping(value = "updateRole")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    private Map<String, Object> updateRole(FrmSysRole role, @ModelAttribute("user") User user) {
        Map<String, Object> result = new HashMap();

        try {
            if (!(sysUtil.isEmptyObject(role.getRoleName()) || sysUtil.isEmptyObject(role.getStatus()))) {
                role.setLastModifier(user.getUserId());
                role.setLastModifyTime(new Date());
                this.roleService.updateRoleByPriKey(role);
                result.put("success", true);
                result.put("msg", "角色信息修改成功！");
            } else {
                result.put("success", false);
                result.put("msg", "角色信息修改失败，填写的角色信息不完整！");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "角色信息修改失败，服务器端处理异常！");
        }

        return result;
    }

    /**
     * 删除角色信息
     *
     * @return
     */
    @RequiresPermissions("SYS_MANAGE_ROLE:::DELETE")
    @RequestMapping(value = "deleteRole")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> deleteRole(long[] roleIds) {
        Map<String, Object> result = new HashMap();
        try {
            if (roleIds != null) {
                for (int i = 0; i < roleIds.length; i++) {
                    this.roleService.deleteRoleByPriKey(roleIds[i]);
                }
                result.put("success", true);
                result.put("msg", "角色信息删除成功！");
            } else {
                result.put("false", false);
                result.put("msg", "角色信息删除失败，服务器端未获得要修改的机构信息！");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("false", false);
            result.put("msg", "角色信息删除失败，服务器端处理异常！");
        }

        return result;
    }

    /**
     * 读取角色模块
     *
     * @param role
     * @return
     */
    @RequestMapping(value = "loadRoleResc")
    @ResponseBody
    public Map<String, Object> loadRoleResc(FrmSysRole role) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<RoleRescNode> loadRoleList = new ArrayList<>();
        DataGrid dataGrid = new DataGrid();

        try {
            loadRoleList.add(this.roleService.loadRoleResc(role));
            result.put("success", "Y");
            result.put("data", loadRoleList);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", "N");
        }

        return result;
    }

//	/**
//	 * 修改角色模块
//	 * @param roleId
//	 * @param rescIdList
//	 * @return
//	 */
//	@RequestMapping(value = "saveRoleResc")
//	@ResponseBody
//	@Transactional(rollbackFor=Exception.class) 
//	public void saveRoleResc(long roleId, List<Long> rescIdList){
//			this.roleService.saveRoleResc(roleId, rescIdList);
//	}

    /**
     * 进入角色权限管理界面
     *
     * @param role
     * @return
     */
    @RequestMapping(value = "toRoleAuthManager")
    public ModelAndView toRoleAuthManager(FrmSysRole role) {

        ModelAndView modelViewRole = new ModelAndView();
        modelViewRole.setViewName("system/roleAuthList");//新的URL
        modelViewRole.addObject("role", role);//传递RoleId

        return modelViewRole;
    }


    /**
     * 查询角色权限信息
     *
     * @return
     */
    @RequestMapping(value = "authList")
    @ResponseBody
    public Map<String, Object> loadAuth(FrmSysRole role) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<RoleAuthNode> roleAuthList = new ArrayList<>();

        try {
            RoleAuthNode roleAuthNode = this.roleService.getRoleAuthTree(role);
            if (roleAuthNode.getChildren().size() > 0) {
                roleAuthList.add(this.roleService.getRoleAuthTree(role));
                result.put("success", "Y");
                result.put("data", roleAuthList);
            } else {
                result.put("success", "N");
                result.put("msg", "角色模块为空，请先分配角色模块！");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", "N");
            result.put("msg", "读取角色权限失败，服务器端未获得角色权限！");
        }

        return result;
    }

    /**
     * 修改角色权限
     *
     * @return
     */
    @RequestMapping(value = "saveRoleAuth")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> saveRoleAuth(long roleId, long[] authIdList) {
        logger.info("修改角色权限开始： roleId" + roleId + " authIdList " + authIdList);
        Map<String, Object> result = new HashMap<String, Object>();
        List<Long> rescIdLongList = new ArrayList<>();
        try {
            if (!"".equals(roleId) && authIdList.length > 0) {
                //根据权限得到对应模块
                rescIdLongList = this.roleService.getRescIdsByAuthIds(authIdList);
                logger.info("根据权限得到对应模块： rescIdLongList" + sysUtil.toJsonStr(rescIdLongList));
                //保存权限
                this.roleService.saveRoleResc(roleId, rescIdLongList);
                logger.info("保存saveRoleResc结束");
                this.roleService.saveRoleAuth(roleId, authIdList);
                logger.info("保存saveRoleAuth结束");
                result.put("success", true);
                result.put("msg", "角色权限设置成功！");
            } else {
                result.put("success", false);
                logger.info("参数为空");
                result.put("msg", "角色权限设置失败，服务器端未获得要修改的角色权限！");
            }
        } catch (Exception e) {
            logger.info("异常：" + e);
            result.put("success", false);
            result.put("msg", "角色权限设置失败，服务器端未获得要修改的角色权限！");
        }

        return result;
    }

    /**
     * 检验角色名
     *
     * @return
     */
    @RequestMapping(value = "checkRoleName")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> checkRoleName(FrmSysRole role) {
        Map<String, Object> result = new HashMap<String, Object>();
        try {
            if (this.roleService.checkRoleName(role.getRoleName())) {
                result.put("success", true);
                result.put("msg", "已有相同角色名，请跟换角色名");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("msg", "角色信息增加失败，服务器端处理异常！");
        }
        return result;
    }

    @RequestMapping("toChangeRole")
    @ResponseBody
    @Transactional(rollbackFor = Exception.class)
    public ModelAndView getRoleList(@ModelAttribute("user") User user) {
        ModelAndView view = new ModelAndView("system/userRoleChange");
        List<FrmSysRole> roleList = null;
        try {
            roleList = roleService.findAllUserId(user.getUserId());
            view.addObject("roleList", roleList);
        } catch (Exception e) {

        }
        return view;
    }

}
