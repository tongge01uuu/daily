package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmSysAuthority;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class AuthorityDao extends BaseMybatisDao<FrmSysAuthority, Long> {

	@Override
	public String getNamespace() {
		return FrmSysAuthorityMapper.class.getCanonicalName();
	}

	/**
	 * 查询菜单对应权限信息
	 * @param rescId
	 * @return
	 */
	public List<FrmSysAuthority> selectByRescId(Long rescId) {
		return getSqlSession().selectList(
				getMybatisMapperNamesapce() + ".selectByRescId", rescId);
	}

	/**
	 * 查询角色对应权限信息
	 * @param roleId
	 * @return
	 */
	public List<FrmSysAuthority> selectByRoleId(Long roleId) {
		return getSqlSession().selectList(
				getMybatisMapperNamesapce() + ".selectByRoleId", roleId);
	}
}
