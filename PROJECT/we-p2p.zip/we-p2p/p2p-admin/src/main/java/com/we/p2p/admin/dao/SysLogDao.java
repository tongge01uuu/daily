package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmSysLog;
import org.springframework.stereotype.Repository;

@Repository
public class SysLogDao extends BaseMybatisDao<FrmSysLog, Long> {

	@Override
	public String getNamespace() {
		return FrmSysLogMapper.class.getCanonicalName();
	}

}
