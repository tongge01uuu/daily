package com.we.p2p.admin.Vo;

import java.math.BigDecimal;

/**
 * Created by rrd on 2016/5/8.
 */
public class ProductOrderVo extends Vo {


    private String createTime;

    private Integer userId;

    private BigDecimal productAmount;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    private String nickName;

    private String investSource;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public BigDecimal getProductAmount() {
        return productAmount;
    }

    public void setProductAmount(BigDecimal productAmount) {
        this.productAmount = productAmount;
    }

    public String getInvestSource() {
        return investSource;
    }

    public void setInvestSource(String investSource) {
        this.investSource = investSource;
    }


}
