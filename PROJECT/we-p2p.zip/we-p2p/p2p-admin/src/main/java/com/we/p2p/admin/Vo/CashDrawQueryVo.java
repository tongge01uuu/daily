package com.we.p2p.admin.Vo;

/**
 * Created by qibaichao on 2016/5/11.
 */
public class CashDrawQueryVo extends Vo  {

    private String selectKey;
    private String selectValue;
    private String cashDrawStatus;
    private String startDate;
    private String endDate;
    public String getSelectKey() {
        return selectKey;
    }

    public void setSelectKey(String selectKey) {
        this.selectKey = selectKey;
    }

    public String getSelectValue() {
        return selectValue;
    }

    public void setSelectValue(String selectValue) {
        this.selectValue = selectValue;
    }

    public String getCashDrawStatus() {
        return cashDrawStatus;
    }

    public void setCashDrawStatus(String cashDrawStatus) {
        this.cashDrawStatus = cashDrawStatus;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
