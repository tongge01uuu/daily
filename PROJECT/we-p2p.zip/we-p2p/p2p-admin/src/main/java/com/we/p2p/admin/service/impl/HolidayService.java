package com.we.p2p.admin.service.impl;

import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.service.HolidayServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.dao.HolidayDao;
import com.we.p2p.admin.entity.FrmHolidayInfo;
import com.we.p2p.admin.entity.FrmHolidayInfoExample;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author hanson
 * @date 2013-8-12
 */
@Service("holidayService")
public class HolidayService implements HolidayServiceI {
	public HolidayDao holidayDao;
	private final String _ORDER_ATTRS = "holiday,holidayType";
	private final String _ORDER_FIELDS = "HOLIDAY,HOLIDAY_TYPE";
	public HolidayDao getHolidayDao() {
		return holidayDao;
	}

	@Autowired
	public void setHolidayDao(HolidayDao holidayDao) {
		this.holidayDao = holidayDao;
	}

	/***
	 * 添加一个假期日
	 * 
	 */
	@Override
	public String add(String date, FrmSysUser user, String type) {
		String result="isFirst";//默认的是添加的日期是没有添加过的
		List<FrmHolidayInfo> list=this.holidayDao.getAll();
		for(FrmHolidayInfo holidayInfo:list){
			if(holidayInfo.getHoliday().equals(date)){
				result="isNotFirst";
				if(type!=null&&!"".equals(type)){
					if(type.equals("W")&&!holidayInfo.getHolidayType().equals("W")){
						result="该日期在法定节假日里面已经添加过了！";  
					}
					if(type.equals("L")&&!holidayInfo.getHolidayType().equals("L")){
						result="该日期在双休日里面已经添加过了！";
					}
				}
				return result;
			}
		}
		FrmHolidayInfo frmHolidayInfo = new FrmHolidayInfo();
		frmHolidayInfo.setHolidayId(KeyGenerator.getNextKey("FRM_HOLIDAY_INFO", "HOLIDAY_ID"));
		frmHolidayInfo.setHoliday(date);
		frmHolidayInfo.setHolidayType(type);
		frmHolidayInfo.setOperId(user.getUserId());
		frmHolidayInfo.setOpDate(new Date());
		this.holidayDao.save(frmHolidayInfo);
		return result;

	}

	/***
	 * 查询 页面List
	 * 
	 * @param pageQuery
	 *            frmHolidyInfo
	 * @return
	 */
	@Override
	public PageList<FrmHolidayInfo> showList(PageQuery pageQuery, FrmHolidayInfo frmHolidayInfo) {
		FrmHolidayInfoExample example = new FrmHolidayInfoExample();
		String order = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS, _ORDER_FIELDS);
		if(order!=null){
			if (!order.equals("")) {
				example.setOrderByClause(order);
			}
		}
		FrmHolidayInfoExample.Criteria criteria=example.createCriteria();
	    if(frmHolidayInfo.getHolidayType()!=null&&!frmHolidayInfo.getHolidayType().equals("")){
	    	criteria.andHolidayTypeEqualTo(frmHolidayInfo.getHolidayType());
	    }else{
	    	criteria.andHolidayTypeEqualTo("W");
	    }
		return this.holidayDao.findPage(pageQuery, example);
	}

	/***
	 * 批量删除
	 * 
	 * @param
	 */
	@Override
	public void delete(String ids) {
		String[] id = ids.split(",");
		List<Long> list = new ArrayList<>();
		for (int i = 0; i < id.length; i++) {
			list.add(Long.parseLong(id[i]));
		}
		FrmHolidayInfoExample example = new FrmHolidayInfoExample();
		example.createCriteria().andHolidayIdIn(list);
		this.holidayDao.deleteByExample(example);
	}

}
