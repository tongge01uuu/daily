package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmHolidayInfo;
import org.springframework.stereotype.Repository;

/**
 *@author hanson
 *@date 2013-8-13
 */
@Repository
public class HolidayDao extends BaseMybatisDao<FrmHolidayInfo, Long> {

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return FrmHolidayInfoMapper.class.getCanonicalName();
	}

}
