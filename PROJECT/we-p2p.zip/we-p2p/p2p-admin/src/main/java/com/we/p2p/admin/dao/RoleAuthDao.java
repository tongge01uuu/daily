package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import org.springframework.stereotype.Repository;

import com.we.p2p.admin.entity.FrmSysRoleAuth;

@Repository
public class RoleAuthDao extends BaseMybatisDao<FrmSysRoleAuth, Long> {

	@Override
	public String getNamespace() {
		return FrmSysRoleAuthMapper.class.getCanonicalName();
	}
}
