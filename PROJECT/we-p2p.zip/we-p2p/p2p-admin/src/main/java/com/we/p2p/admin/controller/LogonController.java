package com.we.p2p.admin.controller;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.service.UserServiceI;
import com.we.p2p.admin.shiro.FrmRealm;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.FrmSysAuthority;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.service.LoginServiceI;
import com.we.p2p.admin.service.impl.UserService;
import com.we.p2p.admin.service.RoleServiceI;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/")
@SessionAttributes("user")
public class LogonController {
    private UserServiceI userService;
    private SysUtil sysUtil;
    private LoginServiceI loginService;
    private RoleServiceI roleService;
    @Autowired
    private FrmRealm frmRealm;

    public FrmRealm getFrmRealm() {
        return frmRealm;
    }

    public void setFrmRealm(FrmRealm frmRealm) {
        this.frmRealm = frmRealm;
    }

    public RoleServiceI getRoleService() {
        return roleService;
    }

    @Autowired
    public void setRoleService(RoleServiceI roleService) {
        this.roleService = roleService;
    }

    public LoginServiceI getLoginService() {
        return loginService;
    }

    @Autowired
    public void setLoginService(LoginServiceI loginService) {
        this.loginService = loginService;
    }

    public UserServiceI getUserService() {
        return userService;
    }

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public SysUtil getSysUtil() {
        return sysUtil;
    }

    @Autowired
    public void setSysUtil(SysUtil sysUtil) {
        this.sysUtil = sysUtil;
    }

    /**
     * 登录方法
     *
     * @param loginId
     * @param password
     * @param model
     * @return
     * @author xtuali 时间：2013-7-1
     */
    @RequestMapping(value = "logon", method = RequestMethod.POST)
    @MethodDesc(value = "用户登录", module = "system")
    @ExtractValue(argIndex = 1, fieldsName = "#self#", fieldsDesc = "登陆名")
    public String logon(@RequestParam("loginId") String loginId,
                        @RequestParam("password") String password, ModelMap model) {
        Subject currUser = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(loginId,
                password);
        token.setRememberMe(true);
        try {
            currUser.login(token);
            // 用户信息保存进入session
            User user = this.loginService.getLoginUserInfo(loginId);
            Session session = currUser.getSession(true);
            if (session.getAttribute("user") != null) {
                session.removeAttribute("user");
            }
            session.setAttribute("user", user);

            if (currUser.isAuthenticated()) {
                return "redirect:/toMain.do";
            }
        } catch (IncorrectCredentialsException e) {
            model.addAttribute("errorMsg", "您所输入的密码不正确!");
        } catch (DisabledAccountException e) {
            model.addAttribute("errorMsg", "当前用户已被禁用，请与系统管理员联系!");
        } catch (ExpiredCredentialsException e) {
            model.addAttribute("errorMsg", "您输入的密码已过有效期!");
        } catch (ExcessiveAttemptsException e) {
            model.addAttribute("errorMsg", "您输入密码的错误次数已过系统设定!");
        } catch (UnknownAccountException e) {
            model.addAttribute("errorMsg", "系统无此用户!");
        } catch (AuthenticationException e) {
            e.printStackTrace();
            model.addAttribute("errorMsg", "未知异常!");
        }
        return "index";
    }


    @RequestMapping(value = "toMain")
    public String toMain() {
        return "main";
    }

    @RequestMapping(value = "toLogin")
    public String toLogin() {
        return "index";
    }

    @RequestMapping(value = "toMenu")
    public String toMenu() {
        return "menu";
    }

    @RequestMapping(value = "toContent")
    public String toContent() {
        return "content";
    }

    @RequestMapping(value = "toHome")
    public String toHome() {
        return "home";
    }

    @RequestMapping(value = "exit")
    public String exit(ModelMap model) {
        Subject currUser = SecurityUtils.getSubject();
        if (currUser.isAuthenticated()) {
            currUser.logout();
        }

        return "index";
    }


    @RequestMapping(value = "sessionOut")
    public ModelAndView sessionOut() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("errorMsg", "当前会话已失效，请重新登陆系统！");
        modelAndView.setViewName("index");

        return modelAndView;
    }

    @RequestMapping(value = "changeRole")
    @MethodDesc(value = "用户角色切换", module = "system")
    public ModelAndView changeRole(Long needChangeRoleId,
                                   @ModelAttribute("user") User user) {
        ModelAndView modelAndView = new ModelAndView();
        Subject currUser = SecurityUtils.getSubject();
        try {
            // 用户信息保存进入session
            Session session = currUser.getSession(false);
            if (user.getRoleId() != null) {// 判断用户是否有角色
                FrmSysRole role = new FrmSysRole();
                role.setRoleId(needChangeRoleId);
                role = roleService.getRoleByPrikey(role);
                if (role != null)
                    user.setCurrRole(role); // 切换角色给用户
                // 角色下的菜单资源
                List<FrmSysResc> rescs = roleService.getRoleRescs(role
                        .getRoleId());
                user.setRescs(rescs);
                // 获取该角色的执行权限
                List<FrmSysAuthority> authoritys = roleService
                        .getRoleAuths(role.getRoleId());
                user.setAuthority(authoritys);
            }
            modelAndView.setViewName("main");
            session.setAttribute("user", user);
            this.frmRealm.clearCachedAuthorizationInfo(currUser.getPrincipal()
                    .toString());

        } catch (Exception e) {
            modelAndView.addObject("errorMsg", "切换角色时出现异常");
            modelAndView.addObject("errorDetail", e.getMessage());
            modelAndView.setViewName("index");
        }
        return modelAndView;
    }


}
