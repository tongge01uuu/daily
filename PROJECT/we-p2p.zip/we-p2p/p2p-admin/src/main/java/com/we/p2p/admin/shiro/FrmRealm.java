package com.we.p2p.admin.shiro;

import com.we.p2p.admin.service.impl.LoginService;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.entity.*;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;



public class FrmRealm extends AuthorizingRealm {
	private LoginService loginService;
	private SysUtil sysUtil;

	public LoginService getLoginService() {
		return loginService;
	}

	@Autowired
	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	@PostConstruct
	public void initCredentialsMatcher() {// MD5加密
		HashedCredentialsMatcher matcher = new HashedCredentialsMatcher("MD5");

		setCredentialsMatcher(matcher);
	}

	/**
	 * 用户的角色权限
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		String loginId = (String) principals.fromRealm(getName()).iterator()
				.next();
		Subject currUser = SecurityUtils.getSubject();
		Session session = currUser.getSession(false);
		User user = (User) session.getAttribute("user");

		if (user != null) {
			List roles = user.getRoles();
			List roleStrs = new ArrayList();
			FrmSysRole tmpRole = null;
			SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();

			if (roles != null) {
				for (int i = 0; i < roles.size(); ++i) {
					tmpRole = (FrmSysRole) roles.get(i);
					roleStrs.add(tmpRole.getRoleName());
				}
			}

			List authorityStrs = new ArrayList(); // 权限码
			List rescs = user.getRescs(); // 用户拥有权限的资源

			// 用户操作权限码生成
			System.out.println("====>>>>>>权限码生成<<<<<<<=====");
			List authorities = user.getAuthority();
			FrmSysResc tmpResc = null;
			FrmSysAuthority tmpAuthority = null;
			// 生成用户的权限字符串，格式为："模块编号:预警信息审核权限:案件信息审核权限:操作权限"
			if (rescs != null) {
				String tmpPermissionStr = null;
				for (int i = 0; i < rescs.size(); ++i) {
					tmpResc = (FrmSysResc) rescs.get(i);
					if ("Y".equals(tmpResc.getIsLeaf())) {
						tmpPermissionStr = tmpResc.getRescNamespace();
						if ("WARNING".equals(tmpResc.getRescNamespace())) {
							tmpPermissionStr += ":"
									+ user.getCurrRole().getRoleName() + "::";
						} else if ("CASE".equals(tmpResc.getRescNamespace())) {
							tmpPermissionStr += "::"
									+ user.getCurrRole().getRoleName() + ":";
						} else {
							tmpPermissionStr += ":::";
						}
						String permissionStr = null;
						if (authorities != null) {
							for (int j = 0; j < authorities.size(); ++j) {
								tmpAuthority = (FrmSysAuthority) authorities
										.get(j);
								if (tmpResc.getRescId() == tmpAuthority
										.getRescId()) {
									permissionStr = tmpPermissionStr
											+ tmpAuthority.getAuthCode();
									System.out.println("=====>>>>>>>权限码："
											+ permissionStr);
									authorityStrs.add(permissionStr);
								}
							}
						}
					}
				}
			}
			System.out.println("====>>>>>>权限码结束<<<<<<<=====");

			info.addRoles(roleStrs);
			info.addStringPermissions(authorityStrs);
			return info;
		} else {
			return null;
		}
	}

	/**
	 * 认证用户
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken authcToken) throws AuthenticationException {
		UsernamePasswordToken token = (UsernamePasswordToken) authcToken;
		FrmSysUser user = this.loginService.getUserInfoByLoginId(token
				.getUsername());

		if (user != null) {
			String password = new String(token.getPassword());

			// if ("1".equals(user.getStatus())) {
			// // 用户被禁用，抛出异常
			// throw new DisabledAccountException("用户已被禁用");
			// }
			// Date currDate = new Date();
			// if (user.getPassInvalidDate() != null) {
			// if (currDate.after(user.getPassInvalidDate())) {
			// // 密码失效，抛出异常
			// throw new ExpiredCredentialsException("用户密码失效");
			// }
			// }
			// if (user.getPassErrCount() > 3) {
			// // 连续验密错误超过系统配置次数，抛出异常
			// throw new ExcessiveAttemptsException("连续验密错误超过系统设置");
			// }

			return new SimpleAuthenticationInfo(user.getLoginId(),
					user.getPassword(), getName());
		} else {
			// 用户不存在，抛出异常
			throw new UnknownAccountException("系统无此用户");
		}
	}

	/**
	 * 更新用户授权信息缓存.
	 */
	public void clearCachedAuthorizationInfo(String principal) {
		SimplePrincipalCollection principals = new SimplePrincipalCollection(
				principal, getName());
		clearCachedAuthorizationInfo(principals);
		System.out.println("====>>>>>>清除授权信息<<<<<<<=====");
	}

	/**
	 * 清除所有用户授权信息缓存.
	 */
	public void clearAllCachedAuthorizationInfo() {
		Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
		if (cache != null) {
			for (Object key : cache.keys()) {
				cache.remove(key);
			}
		}
	}
}
