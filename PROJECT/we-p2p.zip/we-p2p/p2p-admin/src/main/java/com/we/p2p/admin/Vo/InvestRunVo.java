package com.we.p2p.admin.Vo;

/**
 * Created by rrd on 2016/5/17.
 */
public class InvestRunVo extends Vo {

    public String getTotalInvestSum() {
        return totalInvestSum;
    }

    public void setTotalInvestSum(String totalInvestSum) {
        this.totalInvestSum = totalInvestSum;
    }

    public String getTotalPerson() {
        return totalPerson;
    }

    public void setTotalPerson(String totalPerson) {
        this.totalPerson = totalPerson;
    }

    public String getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(String totalSum) {
        this.totalSum = totalSum;
    }

    private String totalSum;
    private String totalPerson;
    private String totalInvestSum;


}
