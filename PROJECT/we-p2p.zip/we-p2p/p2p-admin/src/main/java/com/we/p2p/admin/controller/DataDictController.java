package com.we.p2p.admin.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmDataDict;
import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/dict")
public class DataDictController {
	private SysUtil sysUtil;
	private DataDictServiceI dataDictServiceI;

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	public DataDictServiceI getDataDictServiceI() {
		return dataDictServiceI;
	}

	@Autowired
	@Qualifier("dataDictService")
	public void setDataDictServiceI(DataDictServiceI dataDictServiceI) {
		this.dataDictServiceI = dataDictServiceI;
	}

	@RequiresPermissions("SYS_CFG_DICT:::ADD")
	@RequestMapping(value = "toAddDict")
	@ResponseBody
	public ModelAndView toAddDict() {
		ModelAndView mAndView = new ModelAndView();
		mAndView.addObject("flag", "Add");
		mAndView.setViewName("config/modfiyDict");
		return mAndView;
	}

	@RequiresPermissions("SYS_CFG_DICT:::MODIFY")
	@RequestMapping(value = "toUpdateDict")
	@ResponseBody
	public ModelAndView toUpdateDict(FrmDataDict dict) {
		try {
			dict = this.dataDictServiceI.queryDictById(dict);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("config/modfiyDict");
		modelAndView.addObject("dict", dict);
		modelAndView.addObject("flag", "Update");
		return modelAndView;
	}

	/***
	 * 获取查询信息
	 * 
	 * @param paggQuery
	 *            dict
	 * @return
	 */
	@RequiresPermissions("SYS_CFG_DICT:::LIST")
	@RequestMapping(value = "dictList")
	@ResponseBody
	@MethodDesc(value = "数据字典列表（查询）", module = "系统配置")
	public DataGrid getDataDictList(PageQuery pageQuery, FrmDataDict dict) {
		DataGrid result = new DataGrid();
		PageList<FrmDataDict> dictlist = null;
		try {
			dictlist = this.dataDictServiceI.getDictList(pageQuery, dict);
			if (dictlist.getTotal() != 0) {
				result.setTotal((long) dictlist.getTotal());
				result.setRows(dictlist);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/***
	 * 批量或者单个删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequiresPermissions("SYS_CFG_DICT:::DELETE")
	@RequestMapping(value = "deleteDict")
	@ResponseBody
	@MethodDesc(value = "删除数据字典记录", module = "系统配置")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"删除的数据字典id" })
	public Map<String, Object> deleteDept(String ids) {
		Map<String, Object> result = new HashMap<>();

		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.dataDictServiceI.deleteDataDict(ids);
				result.put("success", true);
				result.put("msg", "数据字典信息删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "数据字典信息删除失败，服务器端未获得要删除的数据字典信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "数据字典信息删除失败，服务器端处理异常！");
		}

		return result;
	}

	/***
	 * 添加修改分派
	 * 
	 * @param dict
	 *            flag response
	 * @return
	 */
	@RequestMapping(value = "modfiyAddOrUpdate")
	@ResponseBody
	@MethodDesc(value = "数据字典的添加（Add）或者修改（Update）", module = "系统配置")
	@ExtractValue(argIndex = 1, fieldsName = { "#self#" }, fieldsDesc = {"操作内容" })
	public void updateOrSave(FrmDataDict dict, String flag, HttpServletResponse response) {
		Map<String, Object> result = new HashMap<>();
		String resultJsonStr = null;

		try {
			if ("Add".equals(flag)) {
				result = this.AddDict(dict);
			} else if ("Update".equals(flag)) {
				result = this.upDateDict(dict);
			} else {
				result.put("success", false);
				result.put("msg", "数据字典添加异常，服务器端无法正常获取请求数据！");
			}
			resultJsonStr = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			e.printStackTrace();
			resultJsonStr = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(resultJsonStr);
				out.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	/***
	 * 添加
	 * 
	 * @param dict
	 * @return
	 */
	@RequiresPermissions("SYS_CFG_DICT:::ADD")
	public Map<String, Object> AddDict(FrmDataDict dict) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (dict != null) {
				this.dataDictServiceI.creatDataDict(dict);
				result.put("success", true);
				result.put("msg", "添加成功！");
			} else {
				result.put("success", false);
				result.put("msg", "添加失败，没有获取到添加信息！");
			}

		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "添加失败，服务器端发生异常");
		}
		return result;

	}

	/***
	 * 更新
	 * 
	 * @param
	 * @return
	 */
	@RequiresPermissions("SYS_CFG_DICT:::MODIFY")
	public Map<String, Object> upDateDict(FrmDataDict dict) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (dict != null) {
				this.dataDictServiceI.updateDataDict(dict);
				result.put("success", true);
				result.put("msg", "更新成功！");
			} else {
				result.put("success", false);
				result.put("msg", "没有获取到要更新的信息");
			}

		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "服务器端发生异常，更新失败！");
		}
		return result;

	}

	/***
	 * 通过传入的参数，获取一字典标题对应的字典项集合
	 * 
	 * @param DICT_TITLE
	 * @return
	 */
	@RequestMapping("getItems")
	@ResponseBody
	public List<FrmDataDictItem> getItems(String DICT_TITLE) {
		DataDictionary dataDictionary = (DataDictionary) this.dataDictServiceI.getDataDictWithItemsByName(DICT_TITLE);
		return dataDictionary.getDictItemList();
	}

	/***
	 * 获取具体的字典项
	 * 
	 * @param dictTitle
	 *            itemCode
	 * @return
	 * 
	 */
	@RequestMapping(value = "getItem")
	@ResponseBody
	public FrmDataDictItem getItem(String dictTitle, String itemCode) {
		FrmDataDictItem item = this.dataDictServiceI.getDataDictItemByTitleAndCode(dictTitle, itemCode);
		return item;
	}

	/***
	 * 通过传入的参数，获取相对应的条件选择表
	 * 
	 * @param dictTitle
	 * @return
	 */
	@RequestMapping("getTableItems")
	@ResponseBody
	public List<FrmDataDictItem> getTables(String dictTitle) {
		List<FrmDataDictItem> result = new ArrayList<>();
		result = this.dataDictServiceI.getTableItem(dictTitle);
		return result;
	}

	/***
	 * 通过父级ID获取到数据字典项
	 * 
	 * @param tableName
	 * @return
	 */
	@RequestMapping("getTableValue")
	@ResponseBody
	public List<FrmDataDictItem> getTableColumn(String tableName) {
		List<FrmDataDictItem> result = new ArrayList<>();
		try {
			result = this.dataDictServiceI.getByTableName(tableName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
