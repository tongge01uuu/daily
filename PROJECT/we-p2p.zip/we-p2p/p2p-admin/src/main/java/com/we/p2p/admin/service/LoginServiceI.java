package com.we.p2p.admin.service;

import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.entity.User;

public interface LoginServiceI {
	public User getLoginUserInfo(String loginId);
	public FrmSysUser getUserInfoByLoginId(String loginId);
}
