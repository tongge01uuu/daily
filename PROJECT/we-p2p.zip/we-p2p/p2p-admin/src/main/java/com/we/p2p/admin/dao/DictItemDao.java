package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmDataDictItem;
import org.springframework.stereotype.Repository;

@Repository
public class DictItemDao extends BaseMybatisDao<FrmDataDictItem, Long> {

	@Override
	public String getNamespace() {
		return FrmDataDictItemMapper.class.getCanonicalName();
	}
}
