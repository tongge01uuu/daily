package com.we.p2p.admin.service;

import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;

import java.util.List;


public interface DictItemServiceI {
	public PageList<FrmDataDictItem> getPageList(PageQuery pg,
												 FrmDataDictItem item);

	public int creatDictItem(FrmDataDictItem item);

	public int deleteItem(String ids);

	public int updateItem(FrmDataDictItem item);

	public FrmDataDictItem getItemById(FrmDataDictItem item);
	
	public String[] getItemTitkeByTabCode(String itemCode[]);
	
	public String getByItemCode(String itemCode);
	
	public List<FrmDataDictItem> getAll();
}
