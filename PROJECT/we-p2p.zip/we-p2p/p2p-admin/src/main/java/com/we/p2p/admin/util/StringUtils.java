package com.we.p2p.admin.util;


public class StringUtils extends org.apache.commons.lang3.StringUtils {
    public static boolean isEmpty(String aStr) {
        return ((aStr == null) || (aStr.trim().length() == 0));
    }

    /**
     * @Author qibaichao
     * @MethodName getZeroString
     * @param length
     * @return
     * @Date 2014年8月14日
     * @Description: Gets the zero string
     */
    public static String getZeroString(int length) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < length; i++) {
            buffer.append("0");
        }
        return buffer.toString();
    }
}

