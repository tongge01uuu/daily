package com.we.p2p.admin.service;

import com.we.p2p.admin.entity.FrmSysLog;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;

public interface LogServiceI {
  public PageList<FrmSysLog> getLogList(PageQuery pageQuery, FrmSysLog log);
  public int deleteByIds(String ids);
}
