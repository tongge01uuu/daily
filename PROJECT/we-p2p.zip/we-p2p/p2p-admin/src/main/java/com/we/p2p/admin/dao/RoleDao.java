package com.we.p2p.admin.dao;

import java.util.List;

import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import org.springframework.stereotype.Repository;

@Repository
public class RoleDao extends BaseMybatisDao<FrmSysRole, Long> {

	@Override
	public String getNamespace() {
		return FrmSysRoleMapper.class.getCanonicalName();
	}
	
	/**
	 * 查询用户所具有的角色信息
	 * @param userId
	 * @return
	 */
	public List<FrmSysRole> selectByUserId(Long userId) {
		return getSqlSession().selectList(getMybatisMapperNamesapce() + ".selectByUserId",
				userId);
	}
}
