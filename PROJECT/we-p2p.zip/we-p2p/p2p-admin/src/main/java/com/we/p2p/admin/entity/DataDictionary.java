package com.we.p2p.admin.entity;

import java.util.List;

public class DataDictionary extends FrmDataDict {
	private List dictItemList;

	public List getDictItemList() {
		return dictItemList;
	}

	public void setDictItemList(List dictItemList) {
		this.dictItemList = dictItemList;
	}
}
