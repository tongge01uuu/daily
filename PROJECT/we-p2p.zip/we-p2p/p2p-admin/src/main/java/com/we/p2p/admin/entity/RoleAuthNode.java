package com.we.p2p.admin.entity;

import java.io.Serializable;
import java.util.List;

public class RoleAuthNode implements Serializable {
	private String pid;
	private String pname;
	private String id;
	private String text;
	private String status = "open";
	private Boolean checked = false;
	private Boolean isAuthId = false;
	private List children;
	
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getChecked() {
		return checked;
	}
	public void setChecked(Boolean checked) {
		this.checked = checked;
	}
	public Boolean getIsAuthId() {
		return isAuthId;
	}
	public void setIsAuthId(Boolean isAuthId) {
		this.isAuthId = isAuthId;
	}
	public List getChildren() {
		return children;
	}
	public void setChildren(List children) {
		this.children = children;
	}
}
