/**
 * 
 */
package com.we.p2p.admin.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author xtuali
 * 从参数中抽取值，与中文对应
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ExtractValue {
	/**
	 * 需要抽取的参数在所有参数中的索引位置
	 * @return
	 * @author xtuali
	 * 时间：2013-8-5
	 */
	int argIndex() default 0;
	
	/**
	 * 需要抽取的参数的字段名字
	 * @return
	 * @author xtuali
	 * 时间：2013-8-5
	 */
	String[] fieldsName() default {};
	/**
	 * 给每一个抽取的字段设置一个描述
	 * @return
	 * @author xtuali
	 * 时间：2013-8-5
	 */
	String[] fieldsDesc() default {};
}
