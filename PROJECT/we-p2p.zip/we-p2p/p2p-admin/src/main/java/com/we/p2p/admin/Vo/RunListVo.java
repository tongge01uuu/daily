package com.we.p2p.admin.Vo;

import java.math.BigDecimal;

/**
 * Created by rrd on 2016/5/15.
 */
public class RunListVo extends Vo {


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;

    private String productName;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getProductTerm() {
        return productTerm;
    }

    public void setProductTerm(String productTerm) {
        this.productTerm = productTerm;
    }

    public BigDecimal getSecurityYearInterest() {
        return securityYearInterest;
    }

    public void setSecurityYearInterest(BigDecimal securityYearInterest) {
        this.securityYearInterest = securityYearInterest;
    }

    public BigDecimal getActualJoinAmount() {
        return actualJoinAmount;
    }

    public void setActualJoinAmount(BigDecimal actualJoinAmount) {
        this.actualJoinAmount = actualJoinAmount;
    }

    public Integer getJoinPersonCount() {
        return joinPersonCount;
    }

    public void setJoinPersonCount(Integer joinPersonCount) {
        this.joinPersonCount = joinPersonCount;
    }

    public String getDateOfInterest() {
        return dateOfInterest;
    }

    public void setDateOfInterest(String dateOfInterest) {
        this.dateOfInterest = dateOfInterest;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String productType;

    private String benefitType;

    private String productTerm;

    private BigDecimal securityYearInterest;

    private BigDecimal actualJoinAmount;

    private Integer joinPersonCount;

    private String dateOfInterest;

    private String maturityDate;

    private String status;

    private String productNameCustom;

    public String getProductNameCustom() {
        return productNameCustom;
    }

    public void setProductNameCustom(String productNameCustom) {
        this.productNameCustom = productNameCustom;
    }
}
