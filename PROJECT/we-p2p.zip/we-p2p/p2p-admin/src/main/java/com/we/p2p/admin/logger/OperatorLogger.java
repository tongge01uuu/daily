/**
 * 
 */
package com.we.p2p.admin.logger;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.FrmSysLog;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.service.SysLogServiceI;
import com.we.p2p.admin.util.ObjectUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;

import javax.servlet.http.HttpSession;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author xtuali
 * 
 */
public class OperatorLogger {

	@Autowired
	private HttpSession session;

	private static volatile ConcurrentMap<String, MethodDesc> methodDescMap = null;

	private static volatile ConcurrentMap<String, ExtractValue> methodExtract = null;

	private static final ExecutorService services = Executors
			.newFixedThreadPool(10);

	@Autowired
	private SysLogServiceI sysLogService;

	public SysLogServiceI getSysLogService() {
		return sysLogService;
	}

	public void setSysLogService(SysLogServiceI sysLogService) {
		this.sysLogService = sysLogService;
	}

	public void setSession(HttpSession session) {
		this.session = session;
	}

	private static ConcurrentMap<String, MethodDesc> getMethodDescMap() {
		if (methodDescMap == null)
			methodDescMap = new ConcurrentHashMap<String, MethodDesc>();
		return methodDescMap;
	}

	private static ConcurrentMap<String, ExtractValue> getMethodExtractMap() {
		if (methodExtract == null)
			methodExtract = new ConcurrentHashMap<String, ExtractValue>();
		return methodExtract;
	}

	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
		MethodDesc desc = null;
		ExtractValue extract = null;
		Method method = ((MethodSignature) pjp.getSignature()).getMethod();

		String key = method.getDeclaringClass().getName() + "."
				+ method.getName();
		Object[] args = pjp.getArgs();
		if (getMethodDescMap().get(key) == null) {
			desc = method.getAnnotation(MethodDesc.class);
			if (desc != null)
				getMethodDescMap().put(key, desc);
		} else {
			desc = getMethodDescMap().get(key);
		}

		if (getMethodExtractMap().get(key) == null) {
			extract = method.getAnnotation(ExtractValue.class);
			if (extract != null)
				getMethodExtractMap().put(key, extract);
		} else {
			extract = getMethodExtractMap().get(key);
		}

		Object arg = null;
		if (extract != null && args.length >= extract.argIndex()) {
			arg = args[extract.argIndex()];
		}
		User user = (User) session.getAttribute("user");
		try {
			Object retVal = pjp.proceed();
			if (desc != null) {
				SaveLog log = new SaveLog(desc, extract, user);
				log.setArgs(arg);
				services.submit(log);
			}
			return retVal;
		} catch (Throwable t) {
			if (desc != null) {
				SaveLog log = new SaveLog(desc, extract, user);
				log.setResult("(失败):" + t.getMessage());
				log.setArgs(arg);
				services.submit(log);
			}
			throw t;
		}
	}

	public User getUser(@ModelAttribute("user") User user) {
		return user;
	}

	/**
	 * 日志保存线程
	 * 
	 * @author xtuali
	 * 
	 */
	private class SaveLog implements Runnable {
		private static final String _SELF = "#self#";
		/**
		 * 描述方法的功能
		 */
		private MethodDesc desc;
		/**
		 * 用来抽取方法的执行结果
		 */
		private ExtractValue extract;

		private User user;

		private String result = "";

		private Object args;

		public Object getArgs() {
			return args;
		}

		public void setArgs(Object args) {
			this.args = args;
		}

		public SaveLog(MethodDesc desc, ExtractValue extract, User u) {
			this.desc = desc;
			this.user = u;
			this.extract = extract;
		}

		public String getResult() {
			return result;
		}

		public void setResult(String result) {
			this.result = result;
		}

		@Override
		public void run() {
			FrmSysLog log = new FrmSysLog();
			log.setOpDate(new Date());
			log.setContent(desc.value() +  getInfluence() + getResult());
			log.setModule(desc.module());
			if (user != null)
				log.setOperId(user.getUserId());
			sysLogService.addLog(log);
		}

		/**
		 * 获取方法执行过程中产生的影响
		 * 
		 * @return
		 * @author xtuali 时间：2013-8-5
		 */
		private String getInfluence() {
			if (extract == null)
				return "";
			Object influence = new Object();
			if (extract.fieldsName().length > 0
					&& _SELF.equals(extract.fieldsName()[0])) {
				influence = "["+getDefaultPrefix(0) + ":" + args+"]";
			} else {
				List influenceList = new ArrayList();
				if (args != null) {
					int i = 0;
					for (String field : extract.fieldsName()) {
						influenceList.add(getDefaultPrefix(i) + ":"
								+ ObjectUtil.getFieldValue(args, field));
						i++;
					}
				}
				influence = influenceList;
			}
			return ", "+influence.toString();
		}

		/**
		 * 获取方法执行过程中产生的影响字符串的前缀
		 * 
		 * @param i
		 * @return
		 * @author xtuali 时间：2013-8-5
		 */
		private String getDefaultPrefix(int i) {
			String[] fieldDesc = extract.fieldsDesc();
			if (fieldDesc.length > i) {
				return fieldDesc[i];
			} else {
				return extract.fieldsName()[i];
			}
		}
	}
}
