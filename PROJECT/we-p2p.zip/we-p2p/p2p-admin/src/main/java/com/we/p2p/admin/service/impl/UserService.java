package com.we.p2p.admin.service.impl;

/**
 * @author  大辉郎
 * @version 
 * Create Date:2013-5-9
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.service.UserServiceI;
import com.we.p2p.admin.util.CriteriaUtil;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.dao.UserDao;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.we.p2p.admin.dao.DeptDao;
import com.we.p2p.admin.dao.FrmSysRoleMapper;
import com.we.p2p.admin.dao.FrmSysUserMapper;
import com.we.p2p.admin.dao.FrmSysUserRoleMapper;
import com.we.p2p.admin.dao.RoleDao;
import com.we.p2p.admin.dao.UserRoleDao;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmSysDept;
import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.entity.FrmSysRoleExample;
import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.entity.FrmSysUserExample;
import com.we.p2p.admin.entity.FrmSysUserRoleExample;
import com.we.p2p.admin.entity.FrmSysUserRole;

@Service("userService")
public class UserService implements UserServiceI {
	
	private final String _ORDER_ATTRS = "name,loginId,description,deptId,status";
	private final String _ORDER_FIELDS = "NAME,LOGIN_ID,DESCRIPTION,DEPT_ID,STATUS";
	
	private SysUtil sysUtil;
	private FrmSysUserMapper usermMapper;
	private UserDao userDao;
	private FrmSysUserMapper userMapper;
	private UserRoleDao userRoleDao;
	private FrmSysRoleMapper roleMapper;
	private FrmSysUserRoleMapper frmSysUserRoleMapper;
	private RoleDao roleDao;
	private DataDictServiceI dataDictServiceI;
	private DeptDao deptDao;

	public FrmSysUserRoleMapper getFrmSysUserRoleMapper() {
		return frmSysUserRoleMapper;
	}

	@Autowired
	public void setFrmSysUserRoleMapper(
			FrmSysUserRoleMapper frmSysUserRoleMapper) {
		this.frmSysUserRoleMapper = frmSysUserRoleMapper;
	}

	public FrmSysRoleMapper getRoleMapper() {
		return roleMapper;
	}

	@Autowired
	public void setRoleMapper(FrmSysRoleMapper roleMapper) {
		this.roleMapper = roleMapper;
	}

	public UserRoleDao getUserRoleDao() {
		return userRoleDao;
	}

	@Autowired
	public void setUserRoleDao(UserRoleDao userRoleDao) {
		this.userRoleDao = userRoleDao;
	}

	public UserDao getUserDao() {
		return userDao;
	}

	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public FrmSysUserMapper getUserMapper() {
		return userMapper;
	}

	@Autowired
	public void setUserMapper(FrmSysUserMapper userMapper) {
		this.userMapper = userMapper;
	}

	public RoleDao getRoleDao() {
		return roleDao;
	}
	
	@Autowired
	public void setRoleDao(RoleDao roleDao) {
		this.roleDao = roleDao;
	}

	public DataDictServiceI getDataDictServiceI() {
		return dataDictServiceI;
	}
	
	@Autowired
	public void setDataDictServiceI(DataDictServiceI dataDictServiceI) {
		this.dataDictServiceI = dataDictServiceI;
	}

	public DeptDao getDeptDao() {
		return deptDao;
	}
	
	@Autowired
	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	public FrmSysUserMapper getUsermMapper() {
		return usermMapper;
	}
	
	@Autowired
	public void setUsermMapper(FrmSysUserMapper usermMapper) {
		this.usermMapper = usermMapper;
	}
	
	public SysUtil getSysUtil() {
		return sysUtil;
	}
	
	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	/**
	 * Description 查询操作
	 * @param pageQuery
	 * @param user
	 * @return PageList
	 * @author 大辉郎
	 */
	@Override
	public PageList<FrmSysUser> getUserPageList(PageQuery pageQuery,
												FrmSysUser user) {

		FrmSysUserExample example = new FrmSysUserExample();
		String name = user.getName();
		Long deptId = user.getDeptId();
		String loginId = user.getLoginId();
		FrmSysUserExample.Criteria criteria = example.createCriteria();

		if (name != null && !"".equals(name)) {
			criteria.andNameLike("%" + name + "%");
		}

		if (loginId != null && !"".equals(loginId)) {
			criteria.andLoginIdLike("%" + loginId + "%");
		}

		if (deptId != null && !"".equals(deptId)) {
			criteria.andDeptIdEqualTo(deptId);
		}
		
		String orderStr = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS,
				_ORDER_FIELDS);
		if (!"".equals(orderStr)) {
			example.setOrderByClause(orderStr);
		}

		return this.userDao.findPage(pageQuery, example);
	}
	
	/**
	 * Description 添加用户信息
	 * 
	 * @param user
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@Override
	public Map<String, Object> addUser(FrmSysUser user,HttpServletRequest request) {
		Map<String, Object> result = new HashMap();
		try {
			if (user != null) {
				String loginId = user.getLoginId();
				FrmSysUser userInfo = new FrmSysUser();
				userInfo = this.getUserByLoginId(loginId);
				if (null == userInfo) {
					/*初始化新增用户密码*/
					user.setPassword(sysUtil.encryptByMd5("888888"));
					user.setCreated(new Date());
					user.setLastLogip(this.getIpAddr(request));
					user.setLastLogin(new Date());
					user.setPassErrCount(0);
					this.createUser(user);
					result.put("success", true);
					result.put("msg", "用户信息添加成功！");
				} else {
					result.put("success", false);
					result.put("msg", "该登录名已经存在，请重新填写！");
				}
			} else {
				result.put("success", false);
				result.put("msg", "用户信息添加失败，服务器端未获得要添加的用户信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户信息添加失败，服务器端未获得要添加的用户信息！");
		}

		return result;
	}
	
	/**
	 * Description 用户管理，添加用户，获取用户IP地址
	 * 
	 * @param 
	 * @return ip
	 * @author 大辉郎 Create Date:2013-8-27
	 */
	@Override
	public String getIpAddr(HttpServletRequest request) {  
	      String ip = request.getHeader("x-forwarded-for");  
	      if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	         ip = request.getHeader("Proxy-Client-IP");  
	     }  
	      if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	         ip = request.getHeader("WL-Proxy-Client-IP");  
	      }  
	     if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
	          ip = request.getRemoteAddr();  
	     }  
	     return ip;  
	} 
	
	/**
	 * Description 新增一个用户
	 * @param user
	 * @return 
	 * @author 大辉郎
	 */
	@Override
	public void createUser(FrmSysUser user) {
		user.setUserId(KeyGenerator.getNextKey("frm_sys_user", "user_id"));
		this.userDao.save(user);

	}

	/**
	 * Description 修改用户信息
	 * 
	 * @param user
	 * @return result
	 * @author 大辉郎 Create Date:2013-5-15
	 */
	@Override
	public Map<String, Object> updateUser(FrmSysUser user) {
		Map<String, Object> result = new HashMap();

		try {
			if (user != null) {
				this.updateByPrimaryKeySelective(user);
				result.put("success", true);
				result.put("msg", "用户信息修改成功！");
			} else {
				result.put("success", false);
				result.put("msg", "用户信息修改失败，服务器端未获得要修改的用户信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "用户信息修改失败，服务器端处理异常！");
		}

		return result;
	}
	
	/**
	 * Description 在用户角色表里新增一条记录
	 * @param userRole
	 * @return 
	 * @author 大辉郎
	 */
	@Override
	public void creatUserRole(FrmSysUserRole userRole) {
		this.userRoleDao.save(userRole);

	}

	/**
	 * Description 修改用户信息
	 * @param users
	 * @return  result
	 * @author 大辉郎
	 */
	@Override
	public int updateByPrimaryKeySelective(FrmSysUser users) {
		int result = this.userDao.updateSelective(users);
		return result;
	}
	
	/**
	 * Description 取消用户默认角色，设置用户默认角色为空
	 * @param users
	 * @return  result
	 * @author 大辉郎
	 */
	@Override
	public int updateByPrimaryKey(FrmSysUser users) {
		int result = this.userDao.update(users);
		return result;
	}
	
	/**
	 * Description 用户管理,删除用户
	 * @param ids
	 * @return  result
	 * @author 大辉郎
	 */
	@Override
	public int deleteUserByKeys(String ids) {
		
		FrmSysUserExample example = new FrmSysUserExample();
		String[] idArray = ids.split(",");
		List idList = new ArrayList();
		
		for (int i = 0; i < idArray.length; ++i) {
			idList.add(idArray[i]);
		}
		example.createCriteria().andUserIdIn(idList);
		int result = this.userDao.deleteByExample(example);
		
		return result;
	}
	
	/**
	 * Description 用户管理,初始化用户密码
	 * @param ids
	 * @return  result
	 * @author 大辉郎
	 */
	public void initializePwd(String ids){
		List<FrmSysUser> all = new ArrayList<>();
		FrmSysUserExample example = new FrmSysUserExample();
		String[] idArray = ids.split(",");
		List idList = new ArrayList();
		
		for (int i = 0; i < idArray.length; ++i) {
			idList.add(idArray[i]);
		}
		example.createCriteria().andUserIdIn(idList);
		all = this.userDao.findAll(example);
		for (FrmSysUser f : all) {
			f.setPassword(sysUtil.encryptByMd5("888888"));
		    this.userDao.updateSelective(f);
		}
	}
	/**
	 * Description 用户管理,删除用户角色
	 * @param ids
	 * @return  result
	 * @author 大辉郎
	 */
	@Override
	public int deleteUserRoleByKeys(String ids) {
		
		String[] idArray = ids.split(",");
		List idList = new ArrayList();
		FrmSysUserRoleExample example = new FrmSysUserRoleExample();
		
		for (int i = 0; i < idArray.length; ++i) {
			idList.add(idArray[i]);
		}
		example.createCriteria().andUserIdIn(idList);
		int result = this.userRoleDao.deleteByExample(example);

		return result;
	}

	/**
	 * Description 通过用户userId得到用户信息
	 * @param user
	 * @return  user
	 * @author 大辉郎
	 */
	@Override
	public FrmSysUser getUserByPriKey(FrmSysUser user) {
		user = this.userDao.getById(user.getUserId());
		return user;
	}
	
	/**
	 * Description 通过userId查询用户信息
	 * @param userId
	 * @return  user
	 * @author 大辉郎
	 */
	@Override
	public FrmSysUser getUserByUserId(long  userId) {
		FrmSysUser user = this.userDao.getById(userId);
		return user;
	}
	
	/**
	 * Description 通过loginId查询用户信息
	 * @param loginId
	 * @return  user
	 * @author 大辉郎
	 */
	@Override
	public FrmSysUser getUserByLoginId(String loginId) {
		FrmSysUserExample example = new FrmSysUserExample();
		FrmSysUser user = new FrmSysUser();
		example.createCriteria().andLoginIdEqualTo(loginId);
		user = this.userDao.findOne(example);
		return user;
	}

	/** (non-Javadoc)
	 * @see UserServiceI#getUserList(FrmSysUser)
	 * @author xtuali
	 * 时间:2013-6-21
	 */
	@Override
	public List<FrmSysUser> getUserList(FrmSysUser user) {
		FrmSysUserExample example = new FrmSysUserExample();
		try {
			CriteriaUtil.initEqualToCriteria(example.createCriteria(), user, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userDao.findAll(example);
	}

	/**
	 * Description 用户管理,角色设置,删除角色
	 * @param userId
	 * @param ids
	 * @return result
	 * @author 大辉郎
	 */
	@Override
	public int deleteUserRole(String ids,long userId) {
		System.out.println("userSERVICEuserId"+userId);
		System.out.println("userSERVICEIDS"+ids);
		String[] idArray = ids.split(",");
		List idList = new ArrayList();
		for (int i = 0; i < idArray.length; ++i) {
			idList.add(idArray[i]);
		}
		FrmSysUserRoleExample example = new FrmSysUserRoleExample();
		example.createCriteria().andUserIdEqualTo(userId).andRoleIdIn(idList);

		int result = this.userRoleDao.deleteByExample(example);
	
		return result;
	}
	
	/**
	 * Description 用户管理,角色设置,添加角色
	 * @param ids
	 * @param userId
	 * @return 
	 * @author 大辉郎
	 */
	@Override
	public void addUserRoles(String ids,long userId) {

		String[] idArray = ids.split(",");
		List idList = new ArrayList();

		for (int i = 0; i < idArray.length; i++) {
			idList.add(idArray[i]);
		}

		FrmSysRoleExample example = new FrmSysRoleExample();
		example.createCriteria().andRoleIdIn(idList);
		List<FrmSysRole> role = this.roleDao.findAll(example);

		if (idArray.length > 0) {
			for (int i = 0; i < idArray.length; i++) {
				FrmSysUserRole userRole = new FrmSysUserRole();
				userRole.setRoleId(role.get(i).getRoleId());
				userRole.setUserId(userId);
				this.frmSysUserRoleMapper.insert(userRole);
			}
		}

	}
	
	/**
	 * 根据传入的数据字典标题获取DICTITEMS
	 * 
	 * @param dictTetle
	 * @return
	 */
	@Override
	public DataDictionary getDictItems(String dictTitle) {
		return (DataDictionary) this.dataDictServiceI.getDataDictWithItemsByName(dictTitle);
	}
	
	/**
	 * Description 用户管理,用户添加,查询数据库里所有的loginId
	 * @param 
	 * @return loginId
	 * @author 大辉郎
	 */
	@Override
	public List getLoginId() {
		

		List loginId = new ArrayList();
		List<FrmSysUser> all = new ArrayList<>();
		all = this.userDao.getAll();
		for (FrmSysUser f : all) {
			loginId.add(f.getLoginId());
		}
		return loginId;
	}
	
	/**
	 * Description 获取所有的部门
	 * @param 
	 * @return list
	 * @author 大辉郎
	 */
	@Override
	public List<FrmSysDept> getDeptAll() {
		List<FrmSysDept> list = this.deptDao.getAll();
		return list;
	}
	
	/**
	 * Description 获取所有的角色
	 * @param 
	 * @return roleList
	 * @author 大辉郎
	 */
	@Override
	public List<FrmSysRole> getRoleAll() {
		List<FrmSysRole> roleList = this.roleDao.getAll();
		return roleList;
	}
	
	/**
	 * Description 获取所有的用户
	 * @param 
	 * @return userList
	 * @author 大辉郎
	 */
	@Override
	public List<FrmSysUser> getUserAll() {
		List<FrmSysUser> userList = this.userDao.getAll();
		return userList;
	}
	
	/**
	 * Description 设置默认角色时,往用户角色表里写一条记录
	 * @param roleId
	 * @param userId
	 * @return 
	 * @author 大辉郎
	 */
	@Override
	public void addDefaultRoles(long roleId,long userId) {
		
	    FrmSysUserRole userRole = new FrmSysUserRole();
		userRole.setRoleId(roleId);
		userRole.setUserId(userId);
		this.frmSysUserRoleMapper.insert(userRole);
	}
}
