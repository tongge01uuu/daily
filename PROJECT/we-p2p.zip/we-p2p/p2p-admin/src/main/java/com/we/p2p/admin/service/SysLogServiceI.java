/**
 * 
 */
package com.we.p2p.admin.service;

import com.we.p2p.admin.entity.FrmSysLog;

/**
 * @author xtuali
 *
 */
public interface SysLogServiceI {
	void addLog(FrmSysLog log);
}
