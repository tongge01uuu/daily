package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import org.springframework.stereotype.Repository;

import com.we.p2p.admin.entity.FrmSysRoleResc;

@Repository
public class RoleRescDao extends BaseMybatisDao<FrmSysRoleResc, Long> {

	@Override
	public String getNamespace() {
		return FrmSysRoleRescMapper.class.getCanonicalName();
	}
}
