package com.we.p2p.admin.dao;

import com.we.p2p.admin.entity.FrmDataDict;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.entity.FrmDataDictItemExample;
import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class DataDictDao extends BaseMybatisDao<FrmDataDict, Long> {
	private DictItemDao dictItemDao;

	public DictItemDao getDictItemDao() {
		return dictItemDao;
	}

	@Autowired
	public void setDictItemDao(DictItemDao dictItemDao) {
		this.dictItemDao = dictItemDao;
	}

	@Override
	public String getNamespace() {
		return FrmDataDictMapper.class.getCanonicalName();
	}

	/**
	 * 通过数据字典title查询数据字典信息
	 * @param dictName
	 * @return
	 */
	public DataDictionary getDataDictByName(String dictName) {
		return (DataDictionary) getSqlSession().selectOne(getMybatisMapperNamesapce() + ".selectByDataDictName",
				dictName);
	}
	
	/**
	 * 查询通过数据字典名称查询数据字典信息及所属字典项信息
	 * @param dictName
	 * @return
	 */
	public DataDictionary getDataDictWithItemsByName(String dictName){
		//查询数据字典信息
		DataDictionary dataDictionary =  getDataDictByName(dictName);
		
		
		//查询数据字典所属数据项信息
        FrmDataDictItemExample itemExample=new FrmDataDictItemExample();
        itemExample.createCriteria().andDictIdEqualTo(dataDictionary.getDictId());
        dataDictionary.setDictItemList(this.dictItemDao.findAll(itemExample));
		
        return dataDictionary;
	}
	/**
	 * 根据字典的title，以及itemCode进行精确查询
	 * @param dictName
	 * @return
	 */
	public FrmDataDictItem getDataDictItemWithNameAndCode(String dictName, String itemCode){
		//查询数据字典信息
		DataDictionary dataDictionary =  getDataDictByName(dictName);
		if(dataDictionary == null){
			throw new NullPointerException("没有找到数据字典："+dictName + " , "+itemCode);
		}
		
		//查询数据字典所属数据项信息
		FrmDataDictItemExample itemExample=new FrmDataDictItemExample();
		FrmDataDictItemExample.Criteria criteria = itemExample.createCriteria();
		criteria.andDictIdEqualTo(dataDictionary.getDictId());
		criteria.andItemCodeEqualTo(itemCode);
		FrmDataDictItem item = this.dictItemDao.findOne(itemExample);
		
		return item;
	}
}
