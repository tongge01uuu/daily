package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.we.p2p.admin.entity.FrmSysLogExample;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.dao.LogDao;
import com.we.p2p.admin.entity.FrmSysLog;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.we.p2p.admin.service.LogServiceI;

@Service("logService")
public class LogService implements LogServiceI {
	private LogDao logDao;

	public LogDao getLogDao() {
		return logDao;
	}

	@Autowired
	public void setLogDao(LogDao logDao) {
		this.logDao = logDao;
	}

	/***
	 * 分页查询 显示日志信息
	 * 
	 * @param pageQuery
	 *            log
	 * @return
	 */
	@Override
	public PageList<FrmSysLog> getLogList(PageQuery pageQuery, FrmSysLog log) {
		FrmSysLogExample example = new FrmSysLogExample();
		FrmSysLogExample.Criteria criteria = example.createCriteria();
		String conntent = log.getContent();
		if (conntent != null && !"".equals(conntent)) {
			criteria.andContentLike("%" + conntent + "%");
		}
		if(log.getModule()!=null&&!log.getModule().equals("")){
			criteria.andModuleLike("%"+log.getModule()+"%");
		}
		return this.logDao.findPage(pageQuery, example);
	}

	/***
	 * 批量删除日志
	 * 
	 * @param ids
	 * @return
	 */
	@Override
	public int deleteByIds(String ids) {
		String[] id = ids.split(",");
		List<Long> idlist = new ArrayList<>();
		for (int i = 0; i < id.length; i++) {
			idlist.add(Long.parseLong(id[i]));
		}
		FrmSysLogExample example = new FrmSysLogExample();
		FrmSysLogExample.Criteria criteria = example.createCriteria();
		criteria.andLogIdIn(idlist);
		return this.logDao.deleteByExample(example);
	}

}
