package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmSysDept;
import org.springframework.stereotype.Repository;

@Repository
public class DeptDao extends BaseMybatisDao<FrmSysDept, Long> {
	
	@Override
	public String getNamespace() {
		return FrmSysDeptMapper.class.getCanonicalName();
	}

}
