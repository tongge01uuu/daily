package com.we.p2p.admin.util;

import java.util.HashMap;
import java.util.Iterator;

/**
 * User:hgq
 * Datetime:2016/5/8 20:54
 */
public class Constant {


    /**
     * 产品状态
     */
    public static final HashMap<Integer, String> PRODUCT_STATUS_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "募集期");
            put(2, "申请期");
            put(3, "已满额");
            put(4, "募集结束");
            put(5, "收益中");
            put(6, "已退出");
            put(7, "草稿");
            put(8, "募集失败");
            put(9, "已删除");
        }
    };


    /**
     * 产品类型
     */
    public static final HashMap<Integer, String> PRODUCT_TYPE_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "理财产品");
            put(2, "直接融资");
            put(3, "收益权转让");

        }
    };

    /**
     * 产品收益类型
     */
    public static final HashMap<Integer, String> PRODUCT_BENEFIT_TYPE_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "保本保息");
            put(2, "保底预期");
            put(3, "保本预期");
            put(4, "非保本预期");
            put(5, "非保本浮动");
            put(6, "保本浮动收益");
            put(7, "保底");
        }
    };

    /**
     * 订单来源
     */
    public static final HashMap<Integer, String> ORDER_SOURCE_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "PC");
            put(2, "ANDROID");
            put(3, "IOS");
        }
    };

    /**
     * 操作状态
     */
    public static final HashMap<Integer, String> OPERATOR_STATUS_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "未付款");
            put(2, "已付款");
            put(3, "已还款");
            put(10, "还款计划已生成");
        }
    };

    /**
     * 用户风险承受级别
     * @param map
     * @param value
     * @return
     */
    public static final HashMap<Integer, String> USER_RISK_MAP = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;
        {
            put(1, "L");
            put(2, "M");
            put(3, "H");
        }
    };

    public static Integer keyInt(HashMap<Integer,String> map, String value)
    {
        Iterator<Integer> it= map.keySet().iterator();
        while(it.hasNext())
        {
            Integer keyInt=it.next();
            if(map.get(keyInt).equals(value))
                return keyInt;
        }
        return null;
    }

}
