package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.we.p2p.admin.dao.DataDictDao;
import com.we.p2p.admin.entity.FrmDataDict;
import com.we.p2p.admin.entity.FrmDataDictExample;
import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.FrmDataDictItemExample;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.dao.DictItemDao;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmDataDictItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service(value = "dataDictService")
public class DataDictService implements DataDictServiceI {
	private DictItemDao itemDao;
	private DataDictDao dictDao;
	private final String _ORDER_ATTRS = "dictTitle,dictDesc,dictType,status";
	private final String _ORDER_FIELDS = "DICT_TITLE,DICT_DESC,DICT_TYPE,STATUS";

	public DataDictDao getDictDao() {
		return dictDao;
	}

	public DictItemDao getItemDao() {
		return itemDao;
	}

	@Autowired
	public void setItemDao(DictItemDao itemDao) {
		this.itemDao = itemDao;
	}

	@Autowired
	public void setDictDao(DataDictDao dictDao) {
		this.dictDao = dictDao;
	}

	/***
	 * 分页**查询
	 * 
	 * @param PageQuery
	 *            dict
	 * @return
	 */
	@Override
	public PageList<FrmDataDict> getDictList(PageQuery pageQuery, FrmDataDict dict) {
		FrmDataDictExample example = new FrmDataDictExample();
		FrmDataDictExample.Criteria criteria = example.createCriteria();
		String dictTitle = dict.getDictTitle();
		String dictDesc = dict.getDictDesc();
		if (dictDesc != null && !"".equals(dictDesc)) {
			criteria.andDictDescLike("%" + dictDesc + "%");
		}
		if (dictTitle != null && !"".equals(dictTitle)) {
			criteria.andDictTitleLike("%" + dictTitle + "%");
		}
		String order = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS, _ORDER_FIELDS);
		if (!order.equals("")) {
			example.setOrderByClause(order);
		}
		return this.dictDao.findPage(pageQuery, example);
	}

	/***
	 * 新增
	 * 
	 * @param dict
	 * @return
	 */
	@CacheEvict(value = "dictCache", allEntries = true)
	@Override
	public int creatDataDict(FrmDataDict dict) {
		dict.setDictId(KeyGenerator.getNextKey("frm_data_dict", "dict_id"));
		return this.dictDao.save(dict);
	}

	/***
	 * 删除(可批量)
	 * 
	 * @param ids
	 * @return
	 */
	@CacheEvict(value = "dictCache", allEntries = true)
	@Override
	public int deleteDataDict(String ids) {
		String[] id = ids.split(",");
		List idlist = new ArrayList();
		for (int i = 0; i < id.length; i++) {
			idlist.add(id[i]);
		}
		FrmDataDictExample example = new FrmDataDictExample();
		FrmDataDictExample.Criteria criteria = example.createCriteria();
		criteria.andDictIdIn(idlist);
		return this.dictDao.deleteByExample(example);
	}

	/***
	 * 更新
	 * 
	 * @param dict
	 * @return
	 */
	@CacheEvict(value = "dictCache", allEntries = true)
	@Override
	public int updateDataDict(FrmDataDict dict) {
		return this.dictDao.update(dict);
	}

	/***
	 * 根据ID主键查询（获取单一结果）
	 * 
	 * @param dict
	 * @return
	 */
	@Override
	public FrmDataDict queryDictById(FrmDataDict dict) {
		return this.dictDao.getById(dict.getDictId());
	}

	/***
	 * 根据数据字典的名字，获取数据字典(并实现缓存机制)
	 * 
	 * @param dictName
	 * @return
	 */
	@Cacheable(value = "dictCache")
	@Override
	public DataDictionary getDataDictWithItemsByName(String dictName) {
		return this.dictDao.getDataDictWithItemsByName(dictName);
	}

	/****
	 * 用于datagird的column的formatter方法
	 * 
	 * @param dictName
	 *            itemCode
	 * @return
	 */
	@Cacheable(value = "dictCache")
	@Override
	public FrmDataDictItem getDataDictItemByTitleAndCode(String dictName, String itemCode) {
		return this.dictDao.getDataDictItemWithNameAndCode(dictName, itemCode);
	}

	/**
	 * 清空数据字典缓存
	 */
	@CacheEvict(value = "dictCache", allEntries = true)
	@Override
	public void reload() {
	}

	/****
	 * 根据数据字典Type获取数据字典集合
	 * 
	 * @param dictType
	 * @return
	 */
	@Cacheable(value = "dictCache")
	public List<FrmDataDict> getByType(String dictType) {
		FrmDataDictExample example = new FrmDataDictExample();
		example.createCriteria().andDictTypeEqualTo(dictType);
		return this.dictDao.findAll(example);
	}

	/***
	 * 获取变量表所对应数据字典项集合
	 * 
	 * @param dictTitle
	 * @return
	 */
	@Override
	public List<FrmDataDictItem> getTableItem(String dictTitle) {

		List<FrmDataDictItem> result = new ArrayList<>();
		List<FrmDataDictItem> items = new ArrayList<>();
		items = this.getDataDictWithItemsByName(dictTitle).getDictItemList();
		for (FrmDataDictItem item : items) {
			if (item.getParentId() == null || "".equals(item.getParentId())) {
				result.add(item);
			}
		}
		return result;
	}

	/***
	 * 根据父级ID获取该父级ID下的所有字典项（用于级联）
	 * 
	 * @param parentId
	 * @return
	 */
	@Override
	public List<FrmDataDictItem> getByTableName(String tableName) {
		List<FrmDataDictItem> result = new ArrayList<>();
		FrmDataDictItemExample example1 = new FrmDataDictItemExample();
		example1.createCriteria().andItemCodeEqualTo(tableName);
		List<FrmDataDictItem> parentTable = this.itemDao.findAll(example1);
		if (parentTable.size() == 1) {
			Long id = parentTable.get(0).getItemId();
			FrmDataDictItemExample example = new FrmDataDictItemExample();
			example.createCriteria().andParentIdEqualTo(id);
			result = this.itemDao.findAll(example);
		}
		return result;
	}
}
