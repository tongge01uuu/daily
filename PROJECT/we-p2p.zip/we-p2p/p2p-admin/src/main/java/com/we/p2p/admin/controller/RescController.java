package com.we.p2p.admin.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.service.RescServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/resc")
public class RescController {
	private RescServiceI rescServiceI;
	private SysUtil sysUtil;
	private DataDictServiceI dataDictServiceI;

	public RescServiceI getRescServiceI() {
		return rescServiceI;
	}

	@Autowired
	@Qualifier("rescService")
	public void setRescServiceI(RescServiceI rescServiceI) {
		this.rescServiceI = rescServiceI;
	}

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	public DataDictServiceI getDataDictServiceI() {
		return dataDictServiceI;
	}

	@Autowired
	@Qualifier("dataDictService")
	public void setDataDictServiceI(DataDictServiceI dataDictServiceI) {
		this.dataDictServiceI = dataDictServiceI;
	}

	/***
	 * 跳转至添加模块页面
	 * 
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_RESC:::ADD")
	@RequestMapping(value = "toAddResc")
	@ResponseBody
	public ModelAndView toAddResc() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("system/modifyRescList");
		modelAndView.addObject("flag", "Add");
		return modelAndView;
	}

	/***
	 * 跳转至修改模块页面
	 * 
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_RESC:::MODIFY")
	@RequestMapping(value = "toupdate")
	@ResponseBody
	public ModelAndView toupdate(FrmSysResc sResc) {
		FrmSysResc resc = new FrmSysResc();
		try {
			resc = this.rescServiceI.getRescById(sResc);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("system/modifyRescList");
		modelAndView.addObject("flag", "Update");
		modelAndView.addObject("resc", resc);
		return modelAndView;
	}

	/***
	 * 分页显示和获取查询结果
	 * 
	 * @param pageQuery
	 *            resc
	 * @return
	 */
	@MethodDesc(value = "模块列表", module = "系统管理")
	@RequiresPermissions("SYS_MANAGE_RESC:::LIST")
	@RequestMapping(value = "rescList")
	@ResponseBody
	public DataGrid getRescList(PageQuery pageQuery, FrmSysResc resc) {
		DataGrid resut = new DataGrid();
		PageList<FrmSysResc> rescList = null;
		rescList = this.rescServiceI.getRescPageList(pageQuery, resc);
		if (rescList.getTotal() != 0) {
			resut.setRows(rescList);
			resut.setTotal((long) rescList.getTotal());
		}
		return resut;
	}

	/***
	 * 删除模块信息（可批量删除）
	 * 
	 * @param ids
	 * @return
	 */
	@MethodDesc(value = "删除模块", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"模块ID" })
	@RequiresPermissions("SYS_MANAGE_RESC:::DELETE")
	@RequestMapping(value = "deleteInfo")
	@ResponseBody
	public Map<String, Object> deleteResc(String ids) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.rescServiceI.deleteDeptByKeys(ids);
				result.put("success", true);
				result.put("msg", "模块信息删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "模块信息删除失败，服务器端未获得要修改的机构信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "模块信息删除失败，服务器端处理异常！");
		}

		return result;
	}

	/***
	 * 添加新模块
	 * 
	 * @param resc
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_RESC:::ADD")
	public HashMap<String, Object> addResc(FrmSysResc resc) {
		HashMap<String, Object> result = new HashMap<>();
		try {
			if (resc != null) {
				this.rescServiceI.createResc(resc);
				result.put("success", true);
				result.put("msg", "模块信息添加成功！");
			} else {
				result.put("success", true);
				result.put("msg", "模块信息添加失败！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "服务器端出现异常");

		}
		return result;
	}

	/***
	 * 更新模块信息
	 * 
	 * @param resc
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_RESC:::MODIFY")
	public Map<String, Object> updateResc(FrmSysResc resc) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (resc != null) {
				this.rescServiceI.updateDeptByPriKey(resc);
				result.put("success", true);
				result.put("msg", "模块信息修改成功！");
			} else {
				result.put("success", false);
				result.put("msg", "模块信息修改失败，服务器端未获得要修改的机构信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "模块信息修改失败，服务器端处理异常！");
		}

		return result;
	}

	/***
	 * 添加或修改模块信息
	 * 
	 * @param resc
	 *            flag out
	 */
	@RequestMapping(value = "updateAndRemove")
	@ResponseBody
	@MethodDesc(value = "添加（Add）或修改（Update）模块", module = "系统管理")
	@ExtractValue(argIndex = 1, fieldsName = { "#self#" }, fieldsDesc = {"操作内容" })
	public void updateAndRemove(FrmSysResc resc, String flag, HttpServletResponse response) {
		Map<String, Object> result = new HashMap<>();
		String resultToJson = null;
		try {
			if ("Add".equals(flag)) {
				result = this.addResc(resc);
			} else if ("Update".equals(flag)) {
				result = this.updateResc(resc);
			} else {
				result.put("success", false);
				result.put("msg", "机构信息添加异常，服务器端无法正常获取请求数据！");
			}
			resultToJson = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			e.printStackTrace();
			resultToJson = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(resultToJson);
				out.flush();
				out.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	/**
	 * 获取父级ID(每一个模块都可能是父级模块)
	 * 
	 * @return
	 * */
	@RequestMapping(value = "getParent")
	@ResponseBody
	public List<FrmSysResc> getParent() {
		return this.rescServiceI.getAll();
	}

	/***
	 * 获取父级ID相同的模块集合
	 * 
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "fromParId")
	@ResponseBody
	public List<FrmSysResc> getHaveSameParentId(Long fromParId) {
		return this.rescServiceI.getHaveSameParentId(fromParId);
	}

	/***
	 * 判断新增时传入的模块名是否重复
	 * 
	 * @param RescName
	 */
	@RequestMapping("checkRescName")
	@ResponseBody
	public void checkRescName(String RescName, HttpServletResponse response,String flag,Long rescId) {
		String result ="1";
		List<FrmSysResc> rescList =this.rescServiceI.getAll();
		try {
			if(flag.equals("Add")){
			for (FrmSysResc resc : rescList) {
				if (RescName.equals(resc.getRescName())) {
					result ="0";
				}
			}
			}else{
				for(FrmSysResc resc : rescList){
					if(RescName.equals(resc.getRescName())&&!rescId.equals(resc.getRescId())){
						result ="0";
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "模块名称检验失败，请重新填写.";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(result);
				out.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
