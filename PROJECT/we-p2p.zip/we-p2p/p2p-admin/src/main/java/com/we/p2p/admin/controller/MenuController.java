package com.we.p2p.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.we.p2p.admin.entity.Menu;
import com.we.p2p.admin.service.MenuServiceI;
import com.we.p2p.admin.entity.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@RequestMapping("/menu")
@SessionAttributes("user")
public class MenuController {
    private MenuServiceI menuService;

    public MenuServiceI getMenuService() {
        return menuService;
    }

    @Autowired
    public void setMenuService(MenuServiceI menuService) {
        this.menuService = menuService;
    }

    @RequiresPermissions("SYS_MANAGE_USER:::LIST")
    @RequestMapping(value = "userList")
    public String toUserList() {
        return "system/userList";
    }

    @RequiresPermissions("SYS_MANAGE_DEPT:::LIST")
    @RequestMapping(value = "deptList")
    public String toDeptList() {
        return "system/deptList";
    }

    @RequiresPermissions("SYS_MANAGE_ROLE:::LIST")
    @RequestMapping(value = "roleList")
    public String toRoleList() {
        return "system/roleList";
    }

    @RequestMapping(value = "modfiyBasicInfo")
    public String toModfiyPswd() {
        Subject currUser = SecurityUtils.getSubject();
        Session session = currUser.getSession(false);
        User user = (User) session.getAttribute("user");
        return "system/modfiyBasicInfo";
    }

    @RequiresPermissions("SYS_MANAGE_RESC:::LIST")
    @RequestMapping(value = "rescList")
    public String toRescLits() {
        return "system/rescList";
    }

    @RequiresPermissions("CLUE_REPORT:::LIST")
    @RequestMapping(value = "clueSubmit")
    public String toClueSubmit() {
        return "clue/clueSubmit";
    }

    @RequiresPermissions("CLUE_CM:::LIST")
    @RequestMapping(value = "clueEstablishMergerCase")
    public String toClueEstablishMergerCase() {
        return "clue/clueEstablishMergerCase";
    }

    @RequiresPermissions("CLUE_QUERY:::LIST")
    @RequestMapping(value = "clueInfo")
    public String toClueInfo() {
        return "clue/clueInfo";
    }

    @RequiresPermissions("CASE_MANAGE_QUERY:::LIST")
    @RequestMapping(value = "caseInfo")
    public String toCaseInfo() {
        return "case/caseInfo";
    }

    @RequiresPermissions("CASE_MANAGE_INSPECT:::LIST")
    @RequestMapping(value = "caseAudit")
    public String toCaseAudit() {
        return "case/caseAudit";
    }

    @RequiresPermissions("SYS_CFG_CARD_LIST:::LIST")
    @RequestMapping(value = "custNameList")
    public String toCustNameList() {
        return "config/custNameList";
    }

    @RequiresPermissions("SYS_CFG_MERCHANT_LIST:::LIST")
    @RequestMapping(value = "merchNameList")
    public String toMerchNameList() {
        return "config/merchNameList";
    }

    @RequestMapping(value = "userRoleChange")
    public String toUserRoleChange() {
        Subject currUser = SecurityUtils.getSubject();
        Session session = currUser.getSession(false);
        User user = (User) session.getAttribute("user");
        return "system/userRoleChange";
    }

    @RequestMapping(value = "clueDealInfoList")
    public String toclueDealInfoList() {
        return "clue/clueDealInfoList";
    }

    @RequestMapping(value = "caseDeal")
    public String toCaseDeal() {
        return "case/selectQueueCaseDeal";
    }

    @RequestMapping(value = "logList")
    public String toLogList() {
        return "system/logList";
    }

    @RequestMapping(value = "dataDict")
    public String toDataDict() {
        return "config/datadict";
    }

    @RequestMapping(value = "merchanInfoList")
    public String merchanInfoList() {
        return "config/merchanInfoList";
    }

    @RequestMapping(value = "paramList")
    public String toparamList() {
        return "config/paramList";
    }

    @RequestMapping(value = "msgTemplateList")
    public String toMsgTemplateList() {
        return "config/msgTemplateList";
    }

    @RequestMapping(value = "holidayList")
    public String toHolidayList() {
        return "config/holidayList";
    }

    @RequiresPermissions("WARNING_MANAGE_QUEUE:::LIST")
    @RequestMapping(value = "warningQueueList")
    public String toWarningQueueList() {
        return "warning/warningQueueList";
    }

    @RequestMapping(value = "toQueryWarning")
    public String toQueryWarning() {
        return "warning/warningList";
    }

    @RequestMapping(value = "togetWarningFromQueue")
    public String togetWarningFromQueue() {
        return "warning/selectQueueGetWarning";
    }

    @RequestMapping(value = "toQueueUser")
    public String toQueueUser() {
        return "warning/warningQueueUserList";
    }

    @RequestMapping(value = "toAssignWarning")
    public String toAssignWarning() {
        return "warning/selectQueueAssignWarning";
    }

    @RequestMapping(value = "toInspectWarning")
    public String toInspectWarning() {
        return "warning/inspectWarningList";
    }

    @RequestMapping(value = "toAssignCase")
    public String toAssignCase() {
        return "case/selectQueueAssignCase";
    }

    @RequestMapping(value = "caseQueueList")
    public String toCaseQueueList() {
        return "case/caseQueueList";
    }

    //@RequiresPermissions("EXCHANGE_MANAGE_PBL:::LIST")
    @RequestMapping(value = "projectList")
    public String toProjectList() {
        return "exchange/projectList";
    }

    //////////////////节假日管理 begin/////////////////////
    @RequestMapping(value = "toHoliday")
    public String toHoliday() {
        return "config/holidayList";
    }

    //////////////////节假日管理 end/////////////////////

	@RequestMapping(value = "loadMenu")
	@ResponseBody
	public Map<String, Object> loadMenu() {
		Map<String, Object> result = new HashMap<String, Object>();
		List<Menu> menuList = null;

		try {
			menuList = this.menuService.loadMenu();
			result.put("success", "Y");
			result.put("data", menuList);
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", "N");
		}

		return result;
	}
}
