package com.we.p2p.admin.Vo;

import java.io.Serializable;

public class Vo implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 1L;

}