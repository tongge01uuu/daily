package com.we.p2p.admin.service.impl;

import com.we.p2p.admin.dao.*;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.service.LoginServiceI;
import com.we.p2p.admin.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Service
public class LoginService implements LoginServiceI {
	private UserDao userDao;
	private RoleDao roleDao;
	private RescDao rescDao;
	private AuthorityDao authorityDao;
	private DeptDao deptDao;
	private SysUtil sysUtil;
	private UserService userService;

	public UserDao getUserDao() {
		return userDao;
	}

	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public UserService getUserService() {
		return userService;
	}

	@Autowired
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	public RoleDao getRoleDao() {
		return roleDao;
	}

	@Autowired
	public void setRoleDao(RoleDao roleDao) {
		this.roleDao = roleDao;
	}

	public RescDao getRescDao() {
		return rescDao;
	}

	@Autowired
	public void setRescDao(RescDao rescDao) {
		this.rescDao = rescDao;
	}

	public AuthorityDao getAuthorityDao() {
		return authorityDao;
	}

	@Autowired
	public void setAuthorityDao(AuthorityDao authorityDao) {
		this.authorityDao = authorityDao;
	}

	public DeptDao getDeptDao() {
		return deptDao;
	}

	@Autowired
	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	/**
	 * 注入session用户登录信息
	 */
	@Override
	public User getLoginUserInfo(String loginId) {
		// 搜索用户
		User user = this.userDao.selectByLoginId(loginId);

		if (user != null) {
			Long roleId = user.getRoleId();
			// 获取登陆时间
			Date date = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			String dateStr = dateFormat.format(date);
			user.setLoginTime(dateStr);

			// 搜索用户所有角色
			List<FrmSysRole> roles = this.roleDao.selectByUserId(user
					.getUserId());
			if (roles != null) {
				user.setRoles(roles);
				FrmSysRole tmpRole = null;
				for (int i = 0; i < roles.size(); ++i) {
					tmpRole = (FrmSysRole) roles.get(i);
					if (tmpRole.getRoleId() == roleId) {
						user.setDefaultRole(tmpRole);
						user.setCurrRole(tmpRole);
						break;
					}
				}
			}

			if (user.getCurrRole() != null) {
				// 查询用户角色对应的菜单
				List<FrmSysResc> rescs = this.rescDao.selectByRoleId(roleId);
				user.setRescs(rescs);

				// 查询角色拥有的操作权限
				List<FrmSysAuthority> authoritys = this.authorityDao
						.selectByRoleId(roleId);
				user.setAuthority(authoritys);
			}
		}
		
		//设置用户机构信息
		FrmSysDept dept=this.deptDao.getById(user.getDeptId());
		user.setDept(dept);

		return user;
	}

	/**
	 * get user info by login id
	 * 
	 * @param loginId
	 * @return
	 */
	@Override
	public FrmSysUser getUserInfoByLoginId(String loginId) {
		FrmSysUserExample example = new FrmSysUserExample();
		example.createCriteria().andLoginIdEqualTo(loginId);

		return this.userDao.findOne(example);
	}
}
