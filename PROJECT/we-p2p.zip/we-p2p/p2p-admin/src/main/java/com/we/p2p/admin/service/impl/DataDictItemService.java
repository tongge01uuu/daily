package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.we.p2p.admin.dao.DictItemDao;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.entity.FrmDataDictItemExample;
import com.we.p2p.admin.service.DictItemServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/***
 * @author hanson
 * @Date 2013-7-3
 */
@Service("dataDictItemService")
public class DataDictItemService implements DictItemServiceI {
	private DictItemDao itemDao;
	private final String _ORDER_ATTRS = "itemCode,itemTitle,itemDesc,itemVal,status";
	private final String _ORDER_FIELDS = "ITEM_CODE,ITEM_TITLE,ITEM_DESC,ITEM_VAL,STATUS";

	public DictItemDao getItemDao() {
		return itemDao;
	}

	@Autowired
	public void setItemDao(DictItemDao itemDao) {
		this.itemDao = itemDao;
	}

	/***
	 * 查询，分页显示
	 * 
	 * @param pg
	 *            item
	 * @return
	 */
	@Override
	public PageList<FrmDataDictItem> getPageList(PageQuery pg, FrmDataDictItem item) {
		FrmDataDictItemExample example = new FrmDataDictItemExample();
		FrmDataDictItemExample.Criteria criteria = example.createCriteria();
		if(item.getDictId()!=null&&!"".equals(item.getDictId())){
			criteria.andDictIdEqualTo(item.getDictId());
		}
		if (item.getItemCode() != null && !"".equals(item.getItemCode())) {
			criteria.andItemCodeLike("%" + item.getItemCode() + "%");
		}
		if (item.getItemDesc() != null && !"".equals(item.getItemDesc())) {
			criteria.andItemDescLike("%" + item.getItemDesc() + "%");
		}
		String order = SysUtil.dealOrderby(pg, _ORDER_ATTRS, _ORDER_FIELDS);
		if (!order.equals("")) {
			example.setOrderByClause(order);
		}
		return this.itemDao.findPage(pg, example);
	}

	/***
	 * 添加一个新的字典项
	 * 
	 * @param item
	 * @return
	 */
	@Override
	public int creatDictItem(FrmDataDictItem item) {
		item.setItemId(KeyGenerator.getNextKey("frm_data_dict_item", "item_id"));
		return this.itemDao.save(item);
	}

	/***
	 * 删除(可批量)
	 * 
	 * @param ids
	 * @return
	 */
	@Override
	public int deleteItem(String ids) {
		String[] id = ids.split(",");
		List idList = new ArrayList();
		for (int i = 0; i < id.length; i++) {
			idList.add(id[i]);
		}
		for (int i = 0; i < idList.size(); i++) {
		}
		FrmDataDictItemExample example = new FrmDataDictItemExample();
		example.createCriteria().andItemIdIn(idList);
		return this.itemDao.deleteByExample(example);
	}

	/***
	 * 更新当前数据字典项
	 * 
	 * @param item
	 * @return
	 */
	@Override
	public int updateItem(FrmDataDictItem item) {
		return this.itemDao.update(item);
	}

	/***
	 * 根据主键获取当前实例
	 * 
	 * @param item
	 * @return
	 */
	@Override
	public FrmDataDictItem getItemById(FrmDataDictItem item) {
		FrmDataDictItem d = this.itemDao.getById(item.getItemId());
		return d;
	}
    /***
     *获取数据字典项中的级联 
     */
	@Override
	public String[] getItemTitkeByTabCode(String[] itemCode) {
		String[] result=new String[2];
		FrmDataDictItemExample example=new FrmDataDictItemExample();
		example.createCriteria().andItemCodeEqualTo(itemCode[0]);
		List<FrmDataDictItem> list=this.itemDao.findAll(example);
		if(list.size()==1){
			FrmDataDictItem f=list.get(0);
			result[0]=f.getItemTitle();
			Long id=f.getItemId();
			FrmDataDictItemExample example2=new FrmDataDictItemExample();
			FrmDataDictItemExample.Criteria criteria=example2.createCriteria();
			criteria.andItemCodeEqualTo(itemCode[1]);
			criteria.andParentIdEqualTo(id);
			List<FrmDataDictItem> list2=this.itemDao.findAll(example2);
			if(list2.size()==1){
				FrmDataDictItem item=list2.get(0);
				result[1]=item.getItemTitle();
			}

		}
				return result;
	}
	
	/***
	 *根据itemCode获取itemTitle 注意：此时的itemCode应该是唯一的，单例的
	 *@param itemCode
	 *@return itemTitle
	 * 
	 */

	@Override
	public String getByItemCode(String itemCode) {
		String result=null;
		FrmDataDictItemExample example=new FrmDataDictItemExample();
		example.createCriteria().andItemCodeEqualTo(itemCode);
		List<FrmDataDictItem> items=this.itemDao.findAll(example);
		System.out.println(items.size());
		if(items.size()==1){
			result=items.get(0).getItemTitle();
		}
		return result;
	}

	@Override
	public List<FrmDataDictItem> getAll() {
		// TODO Auto-generated method stub
		return this.itemDao.getAll();
	}
}
