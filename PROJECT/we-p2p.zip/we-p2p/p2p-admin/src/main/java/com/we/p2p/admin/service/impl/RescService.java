package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.we.p2p.admin.dao.RescDao;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.entity.FrmSysRescExample;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.service.RescServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * 模块管理service
 * 
 * @author hanson
 * @date 2013-6-13
 */
@Service("rescService")
public class RescService implements RescServiceI {

	private RescDao rescDao;
	private DataDictServiceI dataDictServiceI;
	private final String _ORDER_ATTRS = "rescTitle,rescName,rescDesc,rescUrl,rescNamespace,isLeaf,rescStatus";
	private final String _ORDER_FIELDS = "RESC_TITLE,RESC_NAME,RESC_DESC,RESC_URL,RESC_NAMESPACE,IS_LEAF,RESC_STATUS";

	public RescDao getRescDao() {
		return rescDao;
	}

	@Autowired
	public void setRescDao(RescDao rescDao) {
		this.rescDao = rescDao;
	}

	public DataDictServiceI getDataDictServiceI() {
		return dataDictServiceI;
	}

	@Autowired
	@Qualifier("dataDictService")
	public void setDataDictServiceI(DataDictServiceI dataDictServiceI) {
		this.dataDictServiceI = dataDictServiceI;
	}

	/***
	 * 获取Resc列表，用于查询和初始RescList界面
	 * 
	 * @param pageQuery
	 *            resc
	 * @return
	 */
	@Override
	public PageList<FrmSysResc> getRescPageList(PageQuery pageQuery, FrmSysResc resc) {
		FrmSysRescExample example = new FrmSysRescExample();
		String rescName = resc.getRescName();
		String rescDesc = resc.getRescDesc();
		FrmSysRescExample.Criteria criteria = example.createCriteria();
		if (rescName != null && !"".equals(rescName)) {
			criteria.andRescNameLike("%" + rescName + "%");
		}
		if (rescDesc != null && !"".equals(rescDesc)) {
			criteria.andRescDescLike("%" + rescDesc + "%");
		}
		String order = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS, _ORDER_FIELDS);
		if (!order.equals("")) {
			example.setOrderByClause(order);
		}
		return this.rescDao.findPage(pageQuery, example);

	}

	/***
	 * 添加模块
	 * 
	 * @param resc
	 * @return
	 */
	@Override
	public int createResc(FrmSysResc resc) {
		resc.setRescId(KeyGenerator.getNextKey("frm_sys_resc", "resc_id"));
		resc.setRescType("M");
		return this.rescDao.save(resc);
	}

	/***
	 * 修改模块
	 * 
	 * @param resc
	 * @return
	 */
	@Override
	public int updateDeptByPriKey(FrmSysResc resc) {
		return this.rescDao.update(resc);
	}

	/***
	 * 删除模块*(可批量删除)
	 * 
	 * @param ids
	 * @return
	 */
	@Override
	public int deleteDeptByKeys(String ids) {
		String[] idArray = ids.split(",");
		List list = new ArrayList();
		for (int i = 0; i < idArray.length; i++) {
			list.add(idArray[i]);
		}
		FrmSysRescExample example = new FrmSysRescExample();
		example.createCriteria().andRescIdIn(list);
		return this.rescDao.deleteByExample(example);
	}

	/***
	 * 通过主键获取RESC模块对象
	 * 
	 * @param resc
	 *            (通过传入的ID构建的一个对象)
	 * @return
	 */
	@Override
	public FrmSysResc getRescById(FrmSysResc resc) {
		return this.rescDao.getById(resc.getRescId());
	}

	/***
	 * 获取所有的模块
	 * 
	 * @return
	 */
	@Override
	public List<FrmSysResc> getAll() {
		List<FrmSysResc> list = this.rescDao.getAll();
		return list;
	}

	/**
	 * 获取父级ID,资源类型为M，且状态有效的菜单
	 * 
	 * @return
	 * */
	@Override
	public List<FrmSysResc> getParent() {
		FrmSysRescExample example = new FrmSysRescExample();
		FrmSysRescExample.Criteria criteria = example.createCriteria();
		criteria.andRescStatusEqualTo("1");
		criteria.andRescTypeEqualTo("M");
		List<FrmSysResc> list = this.rescDao.findAll(example);
		List<FrmSysResc> result = new ArrayList<>();
		for (FrmSysResc f : list) {
			if (f.getParentId() != null) {
			} else {
				result.add(f);
			}
		}
		FrmSysResc resc = new FrmSysResc();
		resc.setRescName("新根目录，此时父级编号为空");
		result.add(resc);
		return result;
	}

	/**
	 * 获取父级ID相同的模块
	 * 
	 * @return
	 * */
	public List<FrmSysResc> getRescHaveSameParentId(Long id) {
		List<FrmSysResc> list = this.getAll();
		List<FrmSysResc> result = new ArrayList<>();
		for (FrmSysResc f : list) {
			if (f.getParentId() == id) {
				result.add(f);
			}
		}
		return result;
	}

	/***
	 * 获取父级ID相同的模块
	 * 
	 * @param fromParId
	 * @return
	 */
	public List<FrmSysResc> getHaveSameParentId(Long fromParId) {
		FrmSysRescExample example = new FrmSysRescExample();
		example.createCriteria().andParentIdEqualTo(fromParId);
		return this.rescDao.findAll(example);
	}

	/***
	 * 根据传入的数据字典标题获取DICTITEMS
	 * 
	 * @param dictTetle
	 * @return
	 */
	public DataDictionary getDictItems(String dictTitle) {
		return (DataDictionary) this.dataDictServiceI.getDataDictWithItemsByName(dictTitle);
	}

	/***
	 * 根据传入的数据字典标题获取DICTITEMS
	 * 
	 * @param dictTetle
	 * @return
	 */

	@Override
	public FrmDataDictItem getDictItem(String dictTitle, String itemCode) {
		return this.dataDictServiceI.getDataDictItemByTitleAndCode(dictTitle, itemCode);
	}

	/***
	 * 获取父节点集合
	 * 
	 * @return
	 */
	public List<FrmSysResc> getAllCurrentParent() {
		List<FrmSysResc> result = new ArrayList<>();
		List<FrmSysResc> all = this.rescDao.getAll();
		for (FrmSysResc resc : all) {
			if (resc.getParentId() == null) {
				result.add(resc);
			}
		}
		return result;
	}
}
