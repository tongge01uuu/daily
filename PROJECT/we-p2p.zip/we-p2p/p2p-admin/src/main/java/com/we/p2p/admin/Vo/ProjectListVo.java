package com.we.p2p.admin.Vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by shuaizhiguo on 2016/5/11.
 */
public class ProjectListVo  extends Vo{

    private Integer id;

    private String productName;

    private String productType;

    private String productProvider;

    private BigDecimal totalAmountRaised;

    private BigDecimal minTotalAmountRaised;

    private BigDecimal actualJoinAmount;

    private String productTerm;

    private BigDecimal securityYearInterest;

    private Date productPublishTime;

    private Date addedTime;

    private Date shelfTime;

    private String dateOfInterest;

    private String maturityDate;

    private String status;

    private String createPerson;

    private String updatePerson;

    private Date updateTime;

    private String productNameCustom;

    public String getProductNameCustom() {
        return productNameCustom;
    }

    public void setProductNameCustom(String productNameCustom) {
        this.productNameCustom = productNameCustom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreatePerson() {
        return createPerson;
    }

    public void setCreatePerson(String createPerson) {
        this.createPerson = createPerson == null ? null : createPerson.trim();
    }

    public String getUpdatePerson() {
        return updatePerson;
    }

    public void setUpdatePerson(String updatePerson) {
        this.updatePerson = updatePerson == null ? null : updatePerson.trim();
    }

    public String getProductProvider() {
        return productProvider;
    }

    public void setProductProvider(String productProvider) {
        this.productProvider = productProvider == null ? null : productProvider.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductTerm() {
        return productTerm;
    }

    public void setProductTerm(String productTerm) {
        this.productTerm = productTerm == null ? null : productTerm.trim();
    }

    public String getDateOfInterest() {
        return dateOfInterest;
    }

    public void setDateOfInterest(String dateOfInterest) {
        this.dateOfInterest = dateOfInterest == null ? null : dateOfInterest.trim();
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate == null ? null : maturityDate.trim();
    }

    public BigDecimal getSecurityYearInterest() {
        return securityYearInterest;
    }

    public void setSecurityYearInterest(BigDecimal securityYearInterest) {
        this.securityYearInterest = securityYearInterest;
    }

    public BigDecimal getTotalAmountRaised() {
        return totalAmountRaised;
    }

    public void setTotalAmountRaised(BigDecimal totalAmountRaised) {
        this.totalAmountRaised = totalAmountRaised;
    }

    public BigDecimal getMinTotalAmountRaised() {
        return minTotalAmountRaised;
    }

    public void setMinTotalAmountRaised(BigDecimal minTotalAmountRaised) {
        this.minTotalAmountRaised = minTotalAmountRaised;
    }

    public Date getAddedTime() {
        return addedTime;
    }

    public void setAddedTime(Date addedTime) {
        this.addedTime = addedTime;
    }

    public Date getShelfTime() {
        return shelfTime;
    }

    public void setShelfTime(Date shelfTime) {
        this.shelfTime = shelfTime;
    }

    public Date getProductPublishTime() {
        return productPublishTime;
    }

    public void setProductPublishTime(Date productPublishTime) {
        this.productPublishTime = productPublishTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getActualJoinAmount() {
        return actualJoinAmount;
    }

    public void setActualJoinAmount(BigDecimal actualJoinAmount) {
        this.actualJoinAmount = actualJoinAmount;
    }
}
