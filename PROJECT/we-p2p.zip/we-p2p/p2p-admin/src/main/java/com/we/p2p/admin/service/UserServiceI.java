package com.we.p2p.admin.service;

/**
 * @author  大辉郎
 * @version 
 * Create Date：2013-5-9
 */
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmSysDept;
import com.we.p2p.admin.entity.FrmSysUserRole;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.entity.FrmSysRole;

public interface UserServiceI {
	
	public PageList<FrmSysUser> getUserPageList(PageQuery pageQuery, FrmSysUser user);
	public void createUser(FrmSysUser user);
	public Map<String, Object> addUser(FrmSysUser user, HttpServletRequest request);
	public String getIpAddr(HttpServletRequest request);
	public Map<String, Object> updateUser(FrmSysUser user);
	public int updateByPrimaryKeySelective(FrmSysUser users);
	public int updateByPrimaryKey(FrmSysUser users);
	public int deleteUserByKeys(String ids);
	public void initializePwd(String ids);
	public int deleteUserRoleByKeys(String ids);
	public FrmSysUser getUserByPriKey(FrmSysUser user);
	public void creatUserRole(FrmSysUserRole userRole);
	public void addUserRoles(String ids, long userId);
	public DataDictionary getDictItems(String dictTitle);
	public FrmSysUser getUserByUserId(long userId);
	public List getLoginId();
	public FrmSysUser getUserByLoginId(String loginId);
	public List<FrmSysDept> getDeptAll();
	public List<FrmSysUser> getUserAll();
	public List<FrmSysRole> getRoleAll();
	public void addDefaultRoles(long roleId, long userId);
	public int deleteUserRole(String ids, long userId);
	public List<FrmSysUser> getUserList(FrmSysUser user);

}
