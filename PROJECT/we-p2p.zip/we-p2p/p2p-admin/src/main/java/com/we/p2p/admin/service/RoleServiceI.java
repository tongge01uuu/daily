package com.we.p2p.admin.service;

import java.util.List;

import com.we.p2p.admin.entity.FrmSysRole;
import com.we.p2p.admin.entity.RoleRescNode;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.entity.FrmSysAuthority;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.entity.RoleAuthNode;

/**
 * @author 大辉郎
 *
 * 2016-5-9
 */
public interface RoleServiceI {
	public PageList<FrmSysRole> loadRole(PageQuery pageQuery, FrmSysRole role);
	public List<FrmSysRole> getRole(FrmSysRole role, long userId);
	public int createRole(FrmSysRole role);
	public int updateRoleByPriKey(FrmSysRole role);
	public int deleteRoleByPriKey(long roleId);
	public FrmSysRole getRoleByPrikey(FrmSysRole role);
	public RoleRescNode loadRoleResc(FrmSysRole role);
	public int saveRoleResc(long roleId, List<Long> rescId);
	public List getRoleIds();
	
	/**
	 * @author 大辉郎
	 * 时间：2013-6-25
	 */
	public List<FrmSysRole> getUserRole(FrmSysRole role, long userId);
	
	/**
	 * @author 大辉郎
	 * @return
	 * */
	public List getRoleIdInfo(long userId);
	
	//查找用户权限，先不分页
	public RoleAuthNode getRoleAuthTree(FrmSysRole role);
	public int saveRoleAuth(long roleId, long[] authIdList);
	
	public Boolean checkRoleName(String roleName);

	/**
	 * @param role
	 * @return
	 * @author xtuali
	 * 时间：2013-7-9
	 */
	public List<FrmSysRole> findAllByTemplate(FrmSysRole role);
	/**
	 * @param userId
	 * @return
	 * @author xtuali
	 * 时间：2013-7-9
	 * @throws Exception 
	 */
	List<FrmSysRole> findAllUserId(Long userId) throws Exception;
	/**
	 * @param roleId
	 * @return
	 * @author xtuali
	 * 获取角色下的执行权限
	 * 时间：2013-7-10
	 */
	public List<FrmSysAuthority> getRoleAuths(Long roleId);
	/**
	 * 获取角色下的菜单资源
	 * @param roleId
	 * @return
	 * @author xtuali
	 * 时间：2013-7-10
	 */
	public List<FrmSysResc> getRoleRescs(Long roleId);
	/**
	 * 通过权限ID得到模块ID
	 * @param authIdList
	 * @return
	 */
	List<Long> getRescIdsByAuthIds(long[] authIdList);
}
