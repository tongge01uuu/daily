package com.we.p2p.admin.service;

import java.util.List;

import com.we.p2p.admin.entity.FrmSysDept;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.util.orm.page.PageQuery;

public interface DeptServiceI {
	
	public PageList<FrmSysDept> getDeptPageList(PageQuery pageQuery, FrmSysDept dept);
	public int createDept(FrmSysDept dept);
	public int updateDeptByPriKey(FrmSysDept dept);
	public int deleteDeptByKeys(String ids);
	public FrmSysDept getDeptByPriKey(FrmSysDept dept);
	public List<FrmSysDept> getDept();
	public FrmSysDept getDeptByDeptId(long deptId);
}
