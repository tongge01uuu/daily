package com.we.p2p.admin.service;

import java.util.List;

import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.util.orm.page.PageQuery;

public interface RescServiceI {
	public PageList<FrmSysResc> getRescPageList(PageQuery pageQuery, FrmSysResc resc);

	public int createResc(FrmSysResc resc);

	public int updateDeptByPriKey(FrmSysResc resc);

	public int deleteDeptByKeys(String ids);

	public FrmSysResc getRescById(FrmSysResc resc);

	public List<FrmSysResc> getAll();

	public List<FrmSysResc> getParent();

	public List<FrmSysResc> getHaveSameParentId(Long fromParId);

	public DataDictionary getDictItems(String dictTitle);

	/**
	 * @param dictTitle
	 * @param itemCode
	 * @return
	 * @author xtuali 时间：2013-6-26
	 */
	FrmDataDictItem getDictItem(String dictTitle, String itemCode);

	public List<FrmSysResc> getAllCurrentParent();
}
