package com.we.p2p.admin.entity;

import java.io.Serializable;

public class UserRole implements Serializable{
  
	private long roleId;
	private String roleName;
	private String  defaultRole;
	
	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}
	
	
}