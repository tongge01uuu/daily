package com.we.p2p.admin.util;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * @Author WJP
 * @Description:单号生成器
 */
@Service
public class SequencerGenerator {

    private final static String EX = "EX";

    private final static  String FK = "FK";  //付款

    private final static  String TK = "TK"; //退款

    private final static String BATCH = "BATCH"; //自动导入时的批次代码

    @Resource
    private ProductNo productNo;


    /**
     * 产品编码 ：EX+时间17位+序列号3位 共22位
     */
    public String getProductNO() {
        String number = null;
        try {
            number = EX + productNo.getNo();
        } catch (Exception e) {
        }
        return number;
    }

    /**
     * 自动导入时生成的批次代码 ： BATCH +时间17位+序列号3位 共25位
     * @return
     */

    public String getBatchNO() {
        String number = null;
        try {
            number = BATCH + productNo.getNo();
        } catch (Exception e) {
        }
        return number;
    }

    public String getPayNO() {
        String number = null;
        try {
            number = FK + productNo.getNo();
        } catch (Exception e) {
        }
        return number;
    }

    public String getPayBackNO() {
        String number = null;
        try {
            number = TK + productNo.getNo();
        } catch (Exception e) {
        }
        return number;
    }



}
