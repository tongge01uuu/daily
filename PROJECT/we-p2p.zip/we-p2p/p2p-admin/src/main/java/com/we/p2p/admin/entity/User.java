package com.we.p2p.admin.entity;

import java.io.Serializable;
import java.util.List;

public class User extends FrmSysUser implements Serializable{
	private FrmSysRole currRole; // 当前role
	private FrmSysRole defaultRole; // 系统默认role
	private FrmSysDept dept; //所属机构

	private List roles;
	private List rescs;
	private List authority;
	private String loginTime;

	public FrmSysRole getCurrRole() {
		return currRole;
	}

	public void setCurrRole(FrmSysRole currRole) {
		this.currRole = currRole;
	}

	public FrmSysRole getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(FrmSysRole defaultRole) {
		this.defaultRole = defaultRole;
	}

	public List getRoles() {
		return roles;
	}

	public void setRoles(List roles) {
		this.roles = roles;
	}

	public List getRescs() {
		return rescs;
	}

	public void setRescs(List rescs) {
		this.rescs = rescs;
	}

	public List getAuthority() {
		return authority;
	}

	public void setAuthority(List authority) {
		this.authority = authority;
	}

	public String getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}

	public FrmSysDept getDept() {
		return dept;
	}

	public void setDept(FrmSysDept dept) {
		this.dept = dept;
	}

}
