package com.we.p2p.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.we.p2p.admin.entity.Menu;
import com.we.p2p.admin.dao.RescDao;
import com.we.p2p.admin.entity.FrmSysResc;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.service.RescServiceI;
import com.we.p2p.admin.util.ObjectUtil;
import com.we.p2p.admin.service.MenuServiceI;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("menuService")
public class MenuService implements MenuServiceI {
	private RescDao rescDao;
	private RescServiceI rescServiceI;

    private static final Logger log = LoggerFactory.getLogger(MenuService.class);

	public RescServiceI getRescServiceI() {
		return rescServiceI;
	}

	@Autowired
	public void setRescServiceI(RescServiceI rescServiceI) {
		this.rescServiceI = rescServiceI;
	}

	public RescDao getRescDao() {
		return rescDao;
	}

	@Autowired
	public void setRescDao(RescDao rescDao) {
		this.rescDao = rescDao;
	}

	@Override
	public List<Menu> loadMenu() {
		//得到当前用户的当前角色
		Subject currUser = SecurityUtils.getSubject();
		Session session=currUser.getSession(false);
		User user=(User)session.getAttribute("user");
		
		List<Menu> menuList = new ArrayList();
		if(user.getCurrRole()!=null){
			if(!ObjectUtil.isEmptyCollection(this.rescDao.selectByRoleId(user.getCurrRole().getRoleId()))){
				List<FrmSysResc> rescList = this.rescDao.selectByRoleId(user.getCurrRole().getRoleId());
                System.out.println(user.getName());
				this.generatorMenu(rescList, menuList);
			}
		}
//		example.setOrderByClause(" RESC_ID");
		
		return menuList;
	}

	/**
	 * 对系统模块表内数据加工，形成界面展示菜单对象
	 * 
	 * @param rescList
	 * @return
	 */
	private List<Menu> generatorMenu(List<FrmSysResc> rescList,
			List<Menu> menuList) {
		Menu menu = null;
		FrmSysResc sysResc = null;
		
		if (rescList != null && rescList.size() > 0) {
			List<FrmSysResc> parentRescs = new  ArrayList<FrmSysResc>();
			parentRescs.addAll(this.rescServiceI.getAllCurrentParent());
			List<FrmSysResc> repeatRescs = new ArrayList<FrmSysResc>();
			
			//判断父节点是否重复，重复则删除
			for(FrmSysResc parentResc : parentRescs){
				for(FrmSysResc resc : rescList){
					if(parentResc.getRescId()==resc.getRescId()){
						repeatRescs.add(parentResc);
					}
				}
			}
			parentRescs.removeAll(repeatRescs);
			rescList.addAll(parentRescs);
			
			
			if (menuList.size() == 0) {
				for (int i = 0; i < rescList.size(); i++) {
					sysResc = (FrmSysResc) rescList.get(i);
					if (sysResc.getParentId() == null
							|| sysResc.getParentId() == 0L) {
						menu = new Menu();
						menu.setPid("");
						menu.setId(String.valueOf(sysResc.getRescId()));
						menu.setText(sysResc.getRescTitle());
						menu.setUrl(sysResc.getRescUrl()==null?"":sysResc.getRescUrl());
						menu.setIconCls(sysResc.getRescIcon());
						menu.setIsLeaf(sysResc.getIsLeaf());
						menu.setSeq(sysResc.getRescSeq());
						getChild(menu, rescList);
						
						//如果子节点为空则删掉
						if(menu.getChildren().size()==0){
							continue;
						}
						
						menuList.add(menu);
					}
				}
			}
		}

		return menuList;
	}

	/**
	 * 获取menu的子节点
	 * 
	 * @param menu
	 * @param rescList
	 */
	private void getChild(Menu menu, List<FrmSysResc> rescList) {
		if ("Y".equals(menu.getIsLeaf()))
			return;

		Menu childMenu = null;
		FrmSysResc sysResc = null;
		List<Menu> childList = new ArrayList();
		for (int i = 0; i < rescList.size(); i++) {
			sysResc = (FrmSysResc) rescList.get(i);
			if (sysResc.getParentId() != null
					&& Long.parseLong(menu.getId()) == sysResc.getParentId()) {
				childMenu = new Menu();
				childMenu.setPid(menu.getId());
				childMenu.setId(String.valueOf(sysResc.getRescId()));
				childMenu.setText(sysResc.getRescTitle());
				childMenu.setUrl(sysResc.getRescUrl());
				childMenu.setIconCls(sysResc.getRescIcon());
				childMenu.setIsLeaf(sysResc.getIsLeaf());
				childMenu.setSeq(sysResc.getRescSeq());
				getChild(childMenu, rescList);
				childList.add(childMenu);
			}
		}
		menu.setChildren(childList);
	}
}
