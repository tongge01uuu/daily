package com.we.p2p.admin.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.entity.DataDictionary;
import com.we.p2p.admin.entity.FrmDataDict;
import com.we.p2p.admin.service.DataDictServiceI;
import com.we.p2p.admin.service.DictItemServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.FrmDataDictItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "dictItem")
public class DictItemController {
	private SysUtil sysUtil;
	private DictItemServiceI dictItemServiceI;
	private DataDictServiceI dataDictServiceI;

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	public DictItemServiceI getDictItemServiceI() {
		return dictItemServiceI;
	}

	@Autowired
	@Qualifier("dataDictItemService")
	public void setDictItemServiceI(DictItemServiceI dictItemServiceI) {
		this.dictItemServiceI = dictItemServiceI;
	}

	public DataDictServiceI getDataDictServiceI() {
		return dataDictServiceI;
	}
    @Autowired
    @Qualifier("dataDictService")
	public void setDataDictServiceI(DataDictServiceI dataDictServiceI) {
		this.dataDictServiceI = dataDictServiceI;
	}

	/***
	 * 跳转到字典项页面
	 * 
	 * @param item
	 * @return
	 */
	@RequestMapping(value = "toItemList")
	@ResponseBody
	public ModelAndView goItemList(FrmDataDictItem item) {
		ModelAndView view = new ModelAndView();
		FrmDataDict dataDict=new FrmDataDict();
		dataDict.setDictId(item.getDictId());
		FrmDataDict dataDict2=this.dataDictServiceI.queryDictById(dataDict);
		view.addObject("dictTitle",dataDict2.getDictTitle()+"-"+dataDict2.getDictDesc() );
		view.setViewName("config/toItemList");
		view.addObject("item", item);
		
		return view;
	}

	/***
	 * 跳转添加一个新的字典项
	 * 
	 * @param item
	 * @return
	 */
	@RequestMapping(value = "addItem")
	@ResponseBody
	public ModelAndView toAddItem(FrmDataDictItem item) {
		long d = item.getDictId();
		ModelAndView view = new ModelAndView();
		view.setViewName("config/modfiyItem");
		view.addObject("flag", "Add");
		view.addObject("dict", d);
		return view;
	}

	/***
	 *跳转 更新一个新的字典项
	 * 
	 * @param item
	 * @return
	 */
	@RequestMapping(value = "updateItem")
	@ResponseBody
	public ModelAndView toUpdateItem(FrmDataDictItem item) {
		ModelAndView view = new ModelAndView();
		FrmDataDictItem d = new FrmDataDictItem();
		d = this.dictItemServiceI.getItemById(item);
		view.setViewName("config/modfiyItem");
		view.addObject("item", d);
		view.addObject("flag", "Update");
		view.addObject("dict", d.getDictId());
		return view;
	}

	/***
	 * 展示页面，查询
	 * 
	 * @param pg
	 *            item
	 * @return
	 */
	@RequestMapping(value = "itemList")
	@ResponseBody
	@MethodDesc(value = "数据字典列项列表（查询）", module = "系统配置")
	public DataGrid geItemtList(PageQuery pg, FrmDataDictItem item) {
		DataGrid result = new DataGrid();
		PageList<FrmDataDictItem> list = null;
		try {
			list = this.dictItemServiceI.getPageList(pg, item);
			if (list.getTotal() != 0) {
				result.setTotal((long) list.getTotal());
				result.setRows(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/***
	 * 批量删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "deleteItem")
	@ResponseBody
	@MethodDesc(value = "数据字典列项删除", module = "系统配置")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"删除的字典项ID" })
	public Map<String, Object> deleteDict(String ids) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.dictItemServiceI.deleteItem(ids);
				result.put("success", true);
				result.put("msg", "删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "没有获取到要删除的信息");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "删除失败，服务器端发生内部错误");
		}
		return result;
	}

	/***
	 * 用于添加或者更新数据
	 * 
	 * @param item
	 *            flag response
	 */
	@RequestMapping(value = "updateAndAddItem")
	@ResponseBody
	@MethodDesc(value = "数据字典项的添加（Add）或者更新（Update）", module = "系统配置")
	@ExtractValue(argIndex = 1, fieldsName = { "#self#" }, fieldsDesc = {"操作内容" })
	public void updateAndAddItem(FrmDataDictItem item, String flag, HttpServletResponse response) {
		Map<String, Object> result = new HashMap<>();
		String resultJsonStr = null;
		try {
			if (flag.equals("Add")) {
				result = this.addItem(item);
			} else if (flag.equals("Update")) {
				result = this.updateItem(item);
			}
			resultJsonStr = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			e.printStackTrace();
			resultJsonStr = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(resultJsonStr);
				out.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	/***
	 * 用于添加新字典项
	 * 
	 * @param item
	 * @return
	 */
	public Map<String, Object> addItem(FrmDataDictItem item) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (item != null) {
				this.dictItemServiceI.creatDictItem(item);
				result.put("success", true);
				result.put("msg", "数据添加成功");
			} else {
				result.put("success", false);
				result.put("msg", "数据添加失败，为获取到添加信息");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "服务器端出现异常！添加失败");
		}
		return result;
	}

	/***
	 * 更新字典项
	 * 
	 * @param item
	 * @return
	 */
	public Map<String, Object> updateItem(FrmDataDictItem item) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (item != null) {
				this.dictItemServiceI.updateItem(item);
				result.put("success", true);
				result.put("msg", "数据修改成功");
			} else {
				result.put("success", false);
				result.put("msg", "数据修改失败，为获取到添加信息");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "服务器端出现异常！添加失败");
		}
		return result;
	}
	/***
	 * 根据数据字典名称获取数据字典项
	 * @param DICT_TITLE
	 * @return
	 */
	@RequestMapping(value="getItems")
	@ResponseBody
	public List<FrmDataDictItem> getItems(String DICT_TITLE ){
		DataDictionary dataDictionary=(DataDictionary) this.dataDictServiceI.getDataDictWithItemsByName(DICT_TITLE);
		return dataDictionary.getDictItemList();
	}
	
	/***
	 * 获取所有的字典项
	 */
	@RequestMapping(value="getAll")
	@ResponseBody
	public List<FrmDataDictItem> getAll(){
		return this.dictItemServiceI.getAll();
	}
}
