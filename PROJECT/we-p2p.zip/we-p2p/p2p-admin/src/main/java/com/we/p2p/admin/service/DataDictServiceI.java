package com.we.p2p.admin.service;

import java.util.List;

import com.we.p2p.admin.entity.FrmDataDict;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.FrmDataDictItem;
import com.we.p2p.admin.util.orm.page.PageQuery;

public interface DataDictServiceI {
	public PageList<FrmDataDict> getDictList(PageQuery pageQuery, FrmDataDict dict);

	public int creatDataDict(FrmDataDict dict);

	public int deleteDataDict(String ids);

	public int updateDataDict(FrmDataDict dict);

	public FrmDataDict queryDictById(FrmDataDict dict);

	public FrmDataDict getDataDictWithItemsByName(String dictName);

	public void reload(); // 清空数据字典Cache

	public List<FrmDataDict> getByType(String dictType);

	/**
	 * @param dictName
	 * @param itemCode
	 * @return
	 * @author xtuali 时间：2013-6-26
	 */
	public FrmDataDictItem getDataDictItemByTitleAndCode(String dictName, String itemCode);

	public List<FrmDataDictItem> getTableItem(String dictTitle);
	
	public List<FrmDataDictItem> getByTableName(String tableName);
	
}