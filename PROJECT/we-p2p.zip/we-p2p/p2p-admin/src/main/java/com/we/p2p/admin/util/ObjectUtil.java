package com.we.p2p.admin.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class ObjectUtil {

	public static boolean isEmpty(String s) {
		return s == null || "".equals(s);
	}

	public static boolean isEmpty(Long l) {
		return l == null;
	}

	public static boolean isEmpty(AtomicLong l) {
		return l == null;
	}

	/**
	 * 集合c必须不为空，并且size > 0才返回false
	 * 
	 * @param c
	 * @return
	 * @author xtuali 时间：2013-6-8
	 */
	public static boolean isEmptyCollection(Collection c) {
		return c == null || c.size() <= 0;
	}

	/**
	 * 检测对象与对象指定的属性是否为空
	 * 
	 * @param o
	 * @param propertyName
	 * @return
	 */
	public static boolean isObjAndPropertyEmpty(Object o, String propertyName) {
		if (o == null)
			return true;
		Class c = o.getClass();
		Field field = null;
		try {
			field = c.getDeclaredField(propertyName);
			Object fieldValue = getValue(o, field, c);
			return fieldValue == null;
		} catch (NoSuchFieldException e) {
			// e.printStackTrace();
			// logger.warn(c +"does't has field "+ propertyName);
			return true;
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * 将list中元素的propertyName属性的值拿出来生成一个list返回
	 * 
	 * @param list
	 * @param propertyName
	 * @return
	 * @author xtuali 时间：2013-6-8
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List getElementsFieldValue(List list, String propertyName) {
		if (isEmptyCollection(list)) {
			return null;
		}
		Class clazz = list.get(0).getClass();
		List fieldValues = new ArrayList();
		try {
			Field field = clazz.getDeclaredField(propertyName);
			fieldValues.addAll(getFieldValues(list, field, clazz));
			return fieldValues;
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings("finally")
	public static Object getValue(Object obj, Field field, Class clazz) {
		Object fieldValue = null;
		try {
			PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
					clazz);
			Method getter = pd.getReadMethod();
			fieldValue =  getter.invoke(obj, null);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} finally{
			return fieldValue;
		}
	}
	@SuppressWarnings("finally")
	public static Object getFieldValue(Object obj, String fieldName) {
		PropertyDescriptor pd;
		Object fieldValue = null;
		try {
			pd = new PropertyDescriptor(fieldName, obj.getClass());
			Method getter = pd.getReadMethod();
			fieldValue = getter.invoke(obj, null);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} finally{
			return fieldValue;
		}
	}

	/**
	 * 对于获取list中元素的某个属性值，此方法优于上一个方法
	 * 
	 * @param list
	 * @param field
	 * @param clazz
	 * @return
	 * @author xtuali 时间：2013-6-8
	 */
	public static List getFieldValues(List list, Field field, Class clazz) {
		try {
			PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
					clazz);
			Method getter = pd.getReadMethod();
			List fieldValues = new ArrayList();
			for (Object obj : list) {
				fieldValues.add(getter.invoke(obj, null));
			}
			return fieldValues;
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Object setValue(Object obj, Field field, Class clazz,
			Object... parameters) {
		try {
			PropertyDescriptor pd = new PropertyDescriptor(field.getName(),
					clazz);

			Method set = pd.getWriteMethod();
			return set.invoke(obj, parameters);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void addToList(Object[] os, List list) {
		for (Object o : os) {
			list.add(o);
		}
	}
}
