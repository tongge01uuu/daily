package com.we.p2p.admin.service;

import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.FrmHolidayInfo;
import com.we.p2p.admin.util.orm.page.PageQuery;

/**
 *@author hanson
 *@date 2013-8-13
 */
public interface HolidayServiceI {
	public String add(String date, FrmSysUser user, String type);
	public PageList<FrmHolidayInfo> showList(PageQuery pageQuery, FrmHolidayInfo frmHolidayInfo);
	public void delete(String ids);

}
