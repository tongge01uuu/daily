package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmSysLog;
import org.springframework.stereotype.Repository;

@Repository
public class LogDao extends BaseMybatisDao<FrmSysLog, Long> {

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return FrmSysLogMapper.class.getCanonicalName();
	}

}
