package com.we.p2p.admin.service.impl;

import com.we.p2p.admin.dao.DeptDao;
import com.we.p2p.admin.service.DeptServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.entity.FrmSysDept;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.entity.FrmSysDeptExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeptService implements DeptServiceI {
	private final String _ORDER_ATTRS = "deptCode,deptName,deptRegion";
	private final String _ORDER_FIELDS = "DEPT_CODE,DEPT_NAME,DEPT_REGION";
	private DeptDao deptDao;

	public DeptDao getDeptDao() {
		return deptDao;
	}

	@Autowired
	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	@Override
	public PageList<FrmSysDept> getDeptPageList(PageQuery pageQuery,
												FrmSysDept dept) {
		FrmSysDeptExample example = new FrmSysDeptExample();
		String deptCode = dept.getDeptCode();
		String deptName = dept.getDeptName();
		FrmSysDeptExample.Criteria criteria=example.createCriteria();
		if (deptCode != null && !"".equals(deptCode)) {
			criteria.andDeptCodeLike("%" + deptCode + "%");
		}
		if (deptName != null && !"".equals(deptName)) {
			criteria.andDeptNameLike("%" + deptName + "%");
		}

		String orderStr = SysUtil.dealOrderby(pageQuery, _ORDER_ATTRS,
				_ORDER_FIELDS);
		if (!"".equals(orderStr)) {
			example.setOrderByClause(orderStr);
		}

		return this.deptDao.findPage(pageQuery, example);
	}

	@Override
	public int createDept(FrmSysDept dept) {
		dept.setDeptId(KeyGenerator.getNextKey("frm_sys_dept", "dept_id"));
		int result = this.deptDao.save(dept);
		return result;
	}

	@Override
	public int updateDeptByPriKey(FrmSysDept dept) {
		int result = this.deptDao.updateSelective(dept);
		return result;
	}

	@Override
	public int deleteDeptByKeys(String ids) {
		String[] idArray = ids.split(",");
		List idList = new ArrayList();
		for (int i = 0; i < idArray.length; ++i) {
			idList.add(idArray[i]);
		}
		FrmSysDeptExample example = new FrmSysDeptExample();
		example.createCriteria().andDeptIdIn(idList);

		int result = this.deptDao.deleteByExample(example);
		return result;
	}

	@Override
	public FrmSysDept getDeptByPriKey(FrmSysDept dept) {
		dept = this.deptDao.getById(dept.getDeptId());
		return dept;
	}

	@Override
	public List<FrmSysDept> getDept() {
		List<FrmSysDept> depts = this.deptDao.getAll();
		return depts;
	}

	/**
	 * Description 用户管理--用户查询列表，显示部门name
	 * @param deptId
	 * @return dept
	 * @author 大辉郎
	 */
	@Override
	public FrmSysDept getDeptByDeptId(long  deptId){
		FrmSysDept dept = this.deptDao.getById(deptId);
	    return dept;
	}
}
