package com.we.p2p.admin.entity;

import java.io.Serializable;

public class SysParamValue implements Serializable {
	private int paramValue;

	public int getParamValue() {
		return paramValue;
	}

	public void setParamValue(int paramValue) {
		this.paramValue = paramValue;
	}
}
