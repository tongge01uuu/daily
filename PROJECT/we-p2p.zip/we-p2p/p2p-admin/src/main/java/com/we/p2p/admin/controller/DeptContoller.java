package com.we.p2p.admin.controller;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.User;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.service.impl.DeptService;
import com.we.p2p.admin.entity.FrmSysDept;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/dept")
public class DeptContoller {
	private SysUtil sysUtil;
	private DeptService deptService;

	public DeptService getDeptService() {
		return deptService;
	}

	@Autowired
	public void setDeptService(DeptService deptService) {
		this.deptService = deptService;
	}

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	@RequestMapping(value = "toAddDept")
	public ModelAndView toAddDept() {
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("system/modifyDept");
		modelView.addObject("flag", "ADD");
		return modelView;
	}

	@RequestMapping(value = "toUpdateDept")
	public ModelAndView toUpdateDept(FrmSysDept dept) {
		try {
			dept = this.deptService.getDeptByPriKey(dept);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("system/modifyDept");
		modelView.addObject("flag", "UPDATE");
		modelView.addObject("dept", dept);
		return modelView;
	}

	@RequestMapping(value = "deptList")
	@ResponseBody
	@MethodDesc(value = "部门列表（查询）", module = "系统管理")
	public DataGrid getDeptList(PageQuery pageQuery, FrmSysDept dept) {
		PageList<FrmSysDept> deptList = null;
		DataGrid result = new DataGrid();

		try {
			deptList = this.deptService.getDeptPageList(pageQuery, dept);
			if (deptList != null) {
				result.setTotal((long) deptList.getTotal());
				result.setRows(deptList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}


	/**
	 * 添加用户时，取得机构信息
	 * 
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "getDeptAll")
	@ResponseBody
	public List<FrmSysDept> getDeptId() {
		return this.deptService.getDept();
	}

	/**
	 * 添加、修改机构信息
	 * 
	 * @param dept
	 * @return
	 */
	@RequestMapping(value = "modifyDept")
	@ResponseBody
	@MethodDesc(value = "添加（Add）或修改（Update）部门", module = "系统管理")
	@ExtractValue(argIndex = 1, fieldsName = { "#self#" }, fieldsDesc = {"操作内容" })
	public void modifyDept(FrmSysDept dept, String flag,
			HttpServletResponse response) {
		Map<String, Object> result = new HashMap();
		String resultJsonStr = null;

		try {
			if ("ADD".equals(flag)) {
				result = this.addDept(dept);
			} else if ("UPDATE".equals(flag)) {
				result = this.updateDept(dept);
			} else {
				result.put("success", false);
				result.put("msg", "机构信息添加异常，服务器端无法正常获取请求数据！");
			}
			resultJsonStr = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			e.printStackTrace();
			resultJsonStr = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(resultJsonStr);
				out.flush();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * 添加机构信息
	 * 
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_DEPT:::ADD")
	private Map<String, Object> addDept(FrmSysDept dept) {
		Map<String, Object> result = new HashMap();

		try {
			if (dept != null) {
				Subject currUser = SecurityUtils.getSubject();
				Session session = currUser.getSession(false);
				User user=(User)session.getAttribute("user");
				dept.setCreateTime(new Date());
				dept.setCreator(user.getUserId());
				this.deptService.createDept(dept);
				result.put("success", true);
				result.put("msg", "机构信息添加成功！");
			} else {
				result.put("success", false);
				result.put("msg", "机构信息添加失败，服务器端未获得要添加的机构信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "机构信息添加失败，服务器端处理异常！");
		}

		return result;
	}

	/**
	 * 修改机构信息
	 * 
	 * @param dept
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_DEPT:::MODIFY")
	private Map<String, Object> updateDept(FrmSysDept dept) {
		Map<String, Object> result = new HashMap();

		try {
			if (dept != null) {
				this.deptService.updateDeptByPriKey(dept);
				result.put("success", true);
				result.put("msg", "机构信息修改成功！");
			} else {
				result.put("success", false);
				result.put("msg", "机构信息修改失败，服务器端未获得要修改的机构信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "机构信息修改失败，服务器端处理异常！");
		}

		return result;
	}

	/**
	 * 删除机构信息
	 * 
	 * @param ids
	 * @return
	 */
	@MethodDesc(value = "删除部门信息", module = "系统管理")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"部门ID" })
	@RequiresPermissions("SYS_MANAGE_DEPT:::DELETE")
	@RequestMapping(value = "deleteDept")
	@ResponseBody
	public Map<String, Object> deleteDept(String ids) {
		Map<String, Object> result = new HashMap();

		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.deptService.deleteDeptByKeys(ids);
				result.put("success", true);
				result.put("msg", "机构信息删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "机构信息删除失败，服务器端未获得要删除的机构信息！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "机构信息删除失败，服务器端处理异常！");
		}

		return result;
	}
	
	/**
	 * 根据传入的部门ID，获取该部门
	 * @author 大辉郎
	 * @return
	 */
	@RequestMapping("getDept")
	@ResponseBody
	public FrmSysDept getAUser(long deptId){
		FrmSysDept dept=new FrmSysDept();
		try {
			dept=this.deptService.getDeptByDeptId(deptId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dept;
	}
}
