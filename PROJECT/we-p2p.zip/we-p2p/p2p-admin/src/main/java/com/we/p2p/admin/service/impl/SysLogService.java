/**
 * 
 */
package com.we.p2p.admin.service.impl;

import java.util.Date;

import com.we.p2p.admin.dao.SysLogDao;
import com.we.p2p.admin.util.db.KeyGenerator;
import com.we.p2p.admin.entity.FrmSysLog;
import com.we.p2p.admin.service.SysLogServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author xtuali
 *
 */
@Service("sysLogService")
public class SysLogService implements SysLogServiceI {
	
	@Autowired
	private SysLogDao logDao;
	
	
	public SysLogDao getLogDao() {
		return logDao;
	}


	public void setLogDao(SysLogDao logDao) {
		this.logDao = logDao;
	}

	/**
	 * 增加操作日志，主键logid以及操作时间是自动添加
	 * (non-Javadoc)
	 * @see SysLogServiceI#addLog(com.we.p2p.admin.entity.FrmSysLog)
	 * @author xtuali
	 * 时间：2013-7-1
	 */
	@Override
	public void addLog(FrmSysLog log) {
		log.setLogId(KeyGenerator.getNextKey("frm_sys_log", "log_id"));
		log.setOpDate(new Date());
		logDao.save(log);
	}
}
