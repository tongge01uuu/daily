package com.we.p2p.admin.service;

import java.util.List;

import com.we.p2p.admin.entity.Menu;

public interface MenuServiceI {
	public List<Menu> loadMenu();
}
