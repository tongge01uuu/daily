package com.we.p2p.admin.Vo;

import java.math.BigDecimal;

/**
 * Created by rrd on 2016/5/15.
 */
public class ExitListVo extends Vo {

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public String getProductTerm() {
        return productTerm;
    }

    public void setProductTerm(String productTerm) {
        this.productTerm = productTerm;
    }

    public BigDecimal getSecurityYearInterest() {
        return securityYearInterest;
    }

    public void setSecurityYearInterest(BigDecimal securityYearInterest) {
        this.securityYearInterest = securityYearInterest;
    }

    public BigDecimal getActualJoinAmount() {
        return actualJoinAmount;
    }

    public void setActualJoinAmount(BigDecimal actualJoinAmount) {
        this.actualJoinAmount = actualJoinAmount;
    }

    public Integer getJoinPersonCount() {
        return joinPersonCount;
    }

    public void setJoinPersonCount(Integer joinPersonCount) {
        this.joinPersonCount = joinPersonCount;
    }

    public String getDateOfInterest() {
        return dateOfInterest;
    }

    public void setDateOfInterest(String dateOfInterest) {
        this.dateOfInterest = dateOfInterest;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(BigDecimal totalSum) {
        this.totalSum = totalSum;
    }

    public BigDecimal getPreSum() {
        return preSum;
    }

    public void setPreSum(BigDecimal preSum) {
        this.preSum = preSum;
    }

    public BigDecimal getPayedSum() {
        return payedSum;
    }

    public void setPayedSum(BigDecimal payedSum) {
        this.payedSum = payedSum;
    }

    public Integer getPrePerson() {
        return prePerson;
    }

    public void setPrePerson(Integer prePerson) {
        this.prePerson = prePerson;
    }

    public Integer getPayedPerson() {
        return payedPerson;
    }

    public void setPayedPerson(Integer payedPerson) {
        this.payedPerson = payedPerson;
    }

    private Integer id;

    private String productName;

    private String productType;

    private String benefitType;

    private String productTerm;

    private BigDecimal securityYearInterest;

    private BigDecimal actualJoinAmount;

    private Integer joinPersonCount;

    private String dateOfInterest;

    private String maturityDate;

    private String status;

    //还款总金额（本金+利息）（当募集失败状态时为本金）、待付款金额、待付款人数、已付款金额、已付款人数
    private BigDecimal totalSum;

    private BigDecimal preSum;

    private BigDecimal payedSum;

    private Integer prePerson;

    private Integer payedPerson;

    public String getOperateStatus() {
        return operateStatus;
    }

    public void setOperateStatus(String operateStatus) {
        this.operateStatus = operateStatus;
    }

    private String operateStatus;

    private String productNameCustom;

    public String getProductNameCustom() {
        return productNameCustom;
    }

    public void setProductNameCustom(String productNameCustom) {
        this.productNameCustom = productNameCustom;
    }

}
