package com.we.p2p.admin.controller;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.service.HolidayServiceI;
import com.we.p2p.admin.util.SysUtil;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.FrmHolidayInfo;
import com.we.p2p.admin.util.orm.page.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * @author hanson
 * @date 2013-8-12
 */
@Controller
@RequestMapping("holidy")
@SessionAttributes("user")
public class HolidyController {
	private HolidayServiceI holidayServiceI;
	private SysUtil sysUtil;

	public HolidayServiceI getHolidayServiceI() {
		return holidayServiceI;
	}

	@Autowired
	@Qualifier("holidayService")
	public void setHolidayServiceI(HolidayServiceI holidayServiceI) {
		this.holidayServiceI = holidayServiceI;
	}

	public SysUtil getSysUtil() {
		return sysUtil;
	}

	@Autowired
	public void setSysUtil(SysUtil sysUtil) {
		this.sysUtil = sysUtil;
	}

	/***
	 * 转向假期类型选择
	 * 
	 * @param type
	 * @return
	 */
	@RequestMapping("chooseType")
	@ResponseBody
	public ModelAndView chooseType(String dateR) {
		ModelAndView view = new ModelAndView();
		view.addObject("date", dateR);
		view.setViewName("config/holidayType");
		return view;
	}

	/***
	 * 节假日展现
	 * 
	 * @param pageList
	 *            frmHolidayInfo
	 */
	@RequestMapping("showList")
	@ResponseBody
	@MethodDesc(value = "节假日列表", module = "系统配置")
	public DataGrid showList(PageQuery pageQuery, FrmHolidayInfo frmHolidayInfo) {
		DataGrid result = new DataGrid();
		try {
			PageList<FrmHolidayInfo> pageList = this.holidayServiceI.showList(pageQuery,frmHolidayInfo);
			result.setRows(pageList);
			result.setTotal((long) pageList.getTotal());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/***
	 * 添加节假日
	 * 
	 * @return
	 * @param frmHolidayInfo
	 *            response user
	 */
	@RequestMapping("Add")
	@ResponseBody
	@MethodDesc(value = "添加节假日", module = "系统配置")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"添加日期" })
	public void add(String date, HttpServletResponse response, String type, @ModelAttribute("user") FrmSysUser user) {
		String stringToJson = null;
		Map<String, Object> result = new HashMap<>();
		try {
			if (type != null && !type.equals("")) {
				result = this.add(date, user, type);
			} else {
				result.put("success", false);
				result.put("msg", "添加失败，未从前端获取到添加数据！");
			}
			stringToJson = this.sysUtil.toJsonStr(result);
		} catch (Exception e) {
			stringToJson = "{success:false,msg:'Json转换失败！'}";
		} finally {
			try {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.write(stringToJson);
				out.flush();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	public Map<String, Object> add(String date, FrmSysUser user, String type) {
		Map<String, Object> result = new HashMap<>();
		try {
			String info=this.holidayServiceI.add(date, user, type);
			result.put("success", true);
			result.put("msg", "添加节假日成功！");
			result.put("addOrNot",info );
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "添加失败，后台处理异常！");
		}
		return result;
	}

	/***
	 * 删除节假日
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping("delete")
	@ResponseBody
	@MethodDesc(value = "删除节假日", module = "系统配置")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"删除的节假日ID" })
	public Map<String, Object> delete(String ids) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.holidayServiceI.delete(ids);
				result.put("success", true);
				result.put("msg", "删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "删除失败，未从客户端获取到数据！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "服务器端发生异常，删除失败！");
		}
		return result;
	}
}
