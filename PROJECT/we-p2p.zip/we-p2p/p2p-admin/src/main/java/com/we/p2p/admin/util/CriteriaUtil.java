package com.we.p2p.admin.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 操纵每个Example下面的Criteria的方法，目前只写了andXXXEqualTo方法
 * @author xtuali
 * 时间:2013年6月4日
 */
public class CriteriaUtil {
	private static final String PRE = "and";
	private static final String EQUALSTO = "EqualTo";
	private static final String LIKE = "LikeTo";
	
	/**
	 * 从example中取出属性的值，如果不为空则执行criteria的andXXXEqualsTo方法
	 * @param criteria
	 * @param queryObj 执行查询时的查询对象
	 * @param ignoreFields 执行andXXXEqualsTo需要过滤的属性
	 * @return
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	public static Object initEqualToCriteria(Object criteria, Object queryObj, List ignoreFields) throws Exception{
		Class clazz = queryObj.getClass();
		Field[] t_fields = clazz.getDeclaredFields();
		List<Field> fields = new ArrayList<>();
		ObjectUtil.addToList(t_fields, fields);
		//移除需要过滤的属性
		if(!SysUtil.isEmptyCollection(ignoreFields)){
			Iterator<Field> iterator = fields.iterator();
			while(iterator.hasNext()){
				Field f = iterator.next();
				if(ignoreFields.contains(f.getName())){
					iterator.remove();
				}
			}
		}
		for(Field field : fields){
			
			//得到example的field的值
			Object fieldVallue = getValue(queryObj, field, clazz);
			//执行criteria的andXXXEqualsTo方法
			if(fieldVallue == null)
				continue;
			if(String.class.equals(field.getType())){
				if("".equals(fieldVallue)){
					continue;
				}
			}
			String methodName = PRE + SysUtil.changeFirstCharUpper(field.getName()) + EQUALSTO;
			addCondition(criteria, methodName, field.getType(), fieldVallue);
		}
		return criteria;
	}
	
	/**
	 * 执行equals方法
	 * @param criteria
	 * @param queryObj
	 * @param ignoreFields
	 * @return
	 * @throws Exception
	 * @author xtuali
	 * 时间：2013-8-12
	 */
	public static Object initLikeToCriteria(Object criteria, Object queryObj, List ignoreFields) throws Exception{
		Class clazz = queryObj.getClass();
		Field[] t_fields = clazz.getDeclaredFields();
		List<Field> fields = new ArrayList<>();
		ObjectUtil.addToList(t_fields, fields);
		//移除需要过滤的属性
		if(!SysUtil.isEmptyCollection(ignoreFields)){
			Iterator<Field> iterator = fields.iterator();
			while(iterator.hasNext()){
				Field f = iterator.next();
				if(ignoreFields.contains(f.getName())){
					iterator.remove();
				}
			}
		}
		for(Field field : fields){
			//得到example的field的值
			Object fieldVallue = getValue(queryObj, field, clazz);
			//执行criteria的andXXXEqualsTo方法
			if(fieldVallue == null)
				continue;
			if(String.class.equals(field.getType())){
				if("".equals(fieldVallue)){
					continue;
				}
			}
			String methodName = PRE + SysUtil.changeFirstCharUpper(field.getName()) + LIKE;
			addCondition(criteria, methodName, field.getType(), fieldVallue);
		}
		return criteria;
	}
	

	/**
	 * 执行criteria的方法
	 * @param criteria
	 * @param methodName
	 * @param fields
	 * @return
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 */
	private static void addCondition(Object criteria, String methodName, Class parameterTypes, Object...parameters) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Class clazz = criteria.getClass();
		Method method = clazz.getDeclaredMethod(methodName, parameterTypes);
		if(method != null){
			method.invoke(criteria, parameters);
		}
	}

	private static Object getValue(Object obj, Field field, Class clazz){
		try {
			PropertyDescriptor pd = new PropertyDescriptor(field.getName(), clazz);
			Method getter =  pd.getReadMethod();
			return getter.invoke(obj, null);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static Object setValue(Object obj, Field field, Class clazz, Object...parameters){
		try {
			PropertyDescriptor pd = new PropertyDescriptor(field.getName(), clazz);
			
			Method set =  pd.getWriteMethod();
			return set.invoke(obj, parameters);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}
}
