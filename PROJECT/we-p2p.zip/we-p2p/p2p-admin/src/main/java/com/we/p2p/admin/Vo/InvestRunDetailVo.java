package com.we.p2p.admin.Vo;

import java.math.BigDecimal;

/**
 * Created by rrd on 2016/5/17.
 */
public class InvestRunDetailVo extends Vo {

    private String name;

    private BigDecimal Invest;

    private BigDecimal interest;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getInvest() {
        return Invest;
    }

    public void setInvest(BigDecimal invest) {
        Invest = invest;
    }

    public BigDecimal getInterest() {
        return interest;
    }

    public void setInterest(BigDecimal interest) {
        this.interest = interest;
    }

    public BigDecimal getSum() {
        return sum;
    }

    public void setSum(BigDecimal sum) {
        this.sum = sum;
    }

    private BigDecimal sum;

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    private BigDecimal rate;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    private String nickName;

}
