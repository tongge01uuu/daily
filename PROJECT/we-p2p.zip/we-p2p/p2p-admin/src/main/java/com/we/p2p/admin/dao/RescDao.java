package com.we.p2p.admin.dao;

import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.FrmSysResc;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RescDao extends BaseMybatisDao<FrmSysResc, Long> {

	@Override
	public String getNamespace() {
		return FrmSysRescMapper.class.getCanonicalName();
	}

	/**
	 * 查询角色对应的菜单
	 * 
	 * @param roleId
	 * @return
	 */
	public List<FrmSysResc> selectByRoleId(Long roleId) {
		return getSqlSession().selectList(
				getMybatisMapperNamesapce() + ".selectByRoleId", roleId);
	}

	/**
	 * 查询用户编号对应的菜单
	 * 
	 * @param userId
	 * @return
	 */
	public List<FrmSysResc> selectByUserId(Long userId) {
		return getSqlSession().selectList(
				getMybatisMapperNamesapce() + ".selectByUserId", userId);
	}
}
