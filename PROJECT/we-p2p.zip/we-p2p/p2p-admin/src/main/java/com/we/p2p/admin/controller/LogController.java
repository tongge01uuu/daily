package com.we.p2p.admin.controller;

import java.util.HashMap;
import java.util.Map;

import com.we.p2p.admin.annotation.ExtractValue;
import com.we.p2p.admin.util.orm.page.PageList;
import com.we.p2p.admin.annotation.MethodDesc;
import com.we.p2p.admin.entity.DataGrid;
import com.we.p2p.admin.entity.FrmSysLog;
import com.we.p2p.admin.util.orm.page.PageQuery;
import com.we.p2p.admin.service.LogServiceI;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/log")
public class LogController {
	private LogServiceI logServiceI;

	public LogServiceI getLogServiceI() {
		return logServiceI;
	}

	@Autowired
	@Qualifier("logService")
	public void setLogServiceI(LogServiceI logServiceI) {
		this.logServiceI = logServiceI;
	}

	/***
	 * 分页显示日志信息
	 * 
	 * @param pageQuery
	 *            log
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_LOG:::LIST")
	@RequestMapping(value = "toLoglist")
	@ResponseBody
	public DataGrid getLoglist(PageQuery pageQuery, FrmSysLog log) {
		DataGrid result = new DataGrid();
		PageList<FrmSysLog> logList = null;
		try {
			logList = this.logServiceI.getLogList(pageQuery, log);
			if (logList != null) {
				result.setTotal((long) logList.getTotal());
				result.setRows(logList);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/***
	 * 批量删除日志信息
	 * 
	 * @param ids
	 * @return
	 */
	@RequiresPermissions("SYS_MANAGE_LOG:::DELETE")
	@RequestMapping(value = "deleteLogs")
	@ResponseBody
	@MethodDesc(value = "删除日志信息", module = "系统配置")
	@ExtractValue(argIndex = 0, fieldsName = { "#self#" }, fieldsDesc = {"日志ID" })
	public Map<String, Object> deleteDict(String ids) {
		Map<String, Object> result = new HashMap<>();
		try {
			if (ids != null && !"".equals(ids.trim())) {
				this.logServiceI.deleteByIds(ids);
				result.put("success", true);
				result.put("msg", "日志信息删除成功！");
			} else {
				result.put("success", false);
				result.put("msg", "没有获取到要删除的日志信息");
			}
		} catch (Exception e) {
			e.printStackTrace();
			result.put("success", false);
			result.put("msg", "删除失败，服务器端发生内部错误");
		}
		return result;
	}
}
