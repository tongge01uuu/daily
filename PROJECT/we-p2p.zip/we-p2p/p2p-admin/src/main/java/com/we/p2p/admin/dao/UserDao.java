package com.we.p2p.admin.dao;

import com.we.p2p.admin.entity.FrmSysUser;
import com.we.p2p.admin.util.orm.mybatis.BaseMybatisDao;
import com.we.p2p.admin.entity.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDao extends BaseMybatisDao<FrmSysUser, Long> {
	
	@Override
	public String getNamespace() {
		return FrmSysUserMapper.class.getCanonicalName();
	}
	
	/**
	 * 通过数据字典title查询数据字典信息
	 * @return
	 */
	public User selectByLoginId(String longId) {
		return (User) getSqlSession().selectOne(getMybatisMapperNamesapce() + ".selectByLoginId",
				longId);
	}
	
	public List<FrmSysUser> getNoQueueUser(long queueId) {
		
		return  getSqlSession().selectList(getMybatisMapperNamesapce() + ".getNoQueueUser",
				queueId);
	}
}
