package com.we.p2p.admin.util;

public class Constants {

}
